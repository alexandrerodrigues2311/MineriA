# MinerIA V5

python -m pip install -r requirements-v5.txt

python work/experiment_v5.py

Leia work/protocolo_v5.md e outputs/relatorio_v5.md. Versão retrospectiva, sem finalidade de precificação. O código usa o Python e as bibliotecas instaladas quando work/ml_windows não existe.
