"""Finite, predeclared multiclass retrospective experiment; see protocolo_v5.md."""
import os
os.environ['OMP_NUM_THREADS']='4'
os.environ['OPENBLAS_NUM_THREADS']='4'
import sys,pathlib,json,gzip,collections,hashlib,datetime,unicodedata
P=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(P/'work/ml_windows'))
import numpy as np,sklearn,scipy
from sklearn.feature_extraction import DictVectorizer
from sklearn.ensemble import HistGradientBoostingClassifier,ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import f1_score,balanced_accuracy_score,log_loss,confusion_matrix
O=P/'outputs'; src=O/'experimento_v4_congelado.json.gz'
z=json.load(gzip.open(src,'rt',encoding='utf8')); rows=z['rows']; sets=z['sets']
labels=['Arrematada','Conquistada','Livre']; y=np.array([labels.index(r['Situacao']) for r in rows]); rounds=np.array([int(r['Rodada']) for r in rows])
def split(rr,rd):
 te=np.where(rounds==rd)[0]; keys={rows[i]['ProcessoMinerario'] for i in te}
 tr=np.array([i for i,r in enumerate(rows) if rounds[i] in rr and r['ProcessoMinerario'] not in keys])
 assert not ({rows[i]['ProcessoMinerario'] for i in tr}&keys)
 return tr,te
def metrics(t,p):
 if not len(t):return None
 pred=p.argmax(1); oh=np.eye(3)[t]
 return {'n':len(t),'f1_macro':float(f1_score(t,pred,labels=[0,1,2],average='macro',zero_division=0)),'balanced_accuracy':float(balanced_accuracy_score(t,pred)),'log_loss':float(log_loss(t,p,labels=[0,1,2])),'brier_multiclass':float(np.mean(np.sum((oh-p)**2,axis=1))),'confusion':confusion_matrix(t,pred,labels=[0,1,2]).tolist(),'top20':{labels[c]:{'n':int(np.ceil(len(t)*.2)),'precision':float(np.mean(t[np.argsort(-p[:,c],kind='stable')[:int(np.ceil(len(t)*.2))]]==c)),'prevalence':float(np.mean(t==c))} for c in range(3)}}
def fit(key,tr,te):
 prior=np.bincount(y[tr],minlength=3)/len(tr)
 if key=='global':return np.tile(prior,(len(te),1)),None
 if key=='uf':
  groups=collections.defaultdict(list)
  for i in tr:groups[sets['basico'][i]['uf']].append(y[i])
  freq={k:(np.bincount(v,minlength=3)+20*prior)/(len(v)+20) for k,v in groups.items()}
  return np.array([freq.get(sets['basico'][i]['uf'],prior) for i in te]),None
 kind,fs=key.split('_',1); vec=DictVectorizer(sparse=False); a=vec.fit_transform([sets[fs][i] for i in tr]); b=vec.transform([sets[fs][i] for i in te])
 if kind=='linear':m=make_pipeline(StandardScaler(),LogisticRegression(C=.1,max_iter=1200,random_state=42))
 elif kind=='hgb':m=HistGradientBoostingClassifier(max_iter=100,max_leaf_nodes=15,l2_regularization=10,random_state=42)
 else:m=ExtraTreesClassifier(n_estimators=120,max_depth=16,min_samples_leaf=15,max_features=.8,n_jobs=4,random_state=42)
 m.fit(a,y[tr]);return m.predict_proba(b),(vec,m,b)
keys=['global','uf','linear_trajetoria','hgb_basico','hgb_trajetoria','extra_trajetoria']
report={'version':'5','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'labels':labels,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((P/'work/protocolo_v5.md').read_bytes()).hexdigest(),'versions':{'python':sys.version,'sklearn':sklearn.__version__,'numpy':np.__version__,'scipy':scipy.__version__},'validation':{},'status':'retrospectivo','limits':['Rodada 8 previamente examinada; não é validação prospectiva.','Atributos congelados V4; cortes anuais e cobertura de eventos desigual.','Processos excluídos por número; associações entre números diferentes ainda podem atravessar cortes.','Agrupamento mineral retrospectivo; não é classificação atual de minerais críticos.','Pontuações não calibradas para novas rodadas; não estimam preço mínimo.']}
for rr,rd in [([1,2],4),([1,2,3],5)]:
 tr,te=split(rr,rd); d={'train_n':len(tr),'test_n':len(te),'train_rounds':rr,'models':{}}
 for key in keys:
  pr,_=fit(key,tr,te);d['models'][key]=metrics(y[te],pr);print('validation',rd,key,d['models'][key]['f1_macro'],flush=True)
 report['validation'][str(rd)]=d
chosen=max(keys,key=lambda k:np.mean([d['models'][k]['f1_macro'] for d in report['validation'].values()]));report['chosen']=chosen
tr,te=split([1,2,3,4,5],8);probs={};report['test']={'train_n':len(tr),'test_n':len(te),'round':8,'models':{}}
fitted=None
for key in keys:
 p,artifact=fit(key,tr,te);probs[key]=p;report['test']['models'][key]=metrics(y[te],p)
 if key==chosen:fitted=artifact
 print('test',key,report['test']['models'][key]['f1_macro'],flush=True)
rng=np.random.default_rng(42); groups=collections.defaultdict(list)
for j,i in enumerate(te):groups[rows[i]['ProcessoMinerario']].append(j)
groups=list(groups.values());diff=[]
for _ in range(300):
 ix=np.concatenate([groups[k] for k in rng.integers(len(groups),size=len(groups))]);t=y[te[ix]]
 diff.append(f1_score(t,probs[chosen][ix].argmax(1),labels=[0,1,2],average='macro',zero_division=0)-f1_score(t,probs['uf'][ix].argmax(1),labels=[0,1,2],average='macro',zero_division=0))
report['paired_bootstrap_vs_uf_ci95']=np.quantile(diff,[.025,.975]).tolist()
report['permutation_importance']=[]
if fitted:
 vec,m,b=fitted; names=vec.get_feature_names_out();base=report['test']['models'][chosen]['f1_macro']
 families={'UF':[j for j,n in enumerate(names) if n.startswith('uf=')],'Área':[j for j,n in enumerate(names) if n=='log_hectares'],'Ano do processo':[j for j,n in enumerate(names) if n=='ano_processo'],'Regime':[j for j,n in enumerate(names) if n.startswith('regime=')]}
 used={j for v in families.values() for j in v};families['Histórico administrativo']=[j for j in range(len(names)) if j not in used]
 for name,cols in families.items():
  if not cols:continue
  drops=[]
  for _ in range(5):
   a=b.copy(); ix=rng.permutation(len(a));a[:,cols]=b[ix][:,cols];drops.append(base-f1_score(y[te],m.predict(a),labels=[0,1,2],average='macro',zero_division=0))
  report['permutation_importance'].append({'family':name,'mean_f1_drop':float(np.mean(drops)),'values':drops})
classification=json.loads((O/'auditoria_minerais_estrategicos.json').read_text(encoding='utf8'));overview=json.loads((P/'painel-anm/dist/overview.json').read_text(encoding='utf8'))
def norm(s):return ''.join(c for c in unicodedata.normalize('NFD',s.upper().strip()) if unicodedata.category(c)!='Mn').removeprefix('MINERIO DE ')
names={norm(n):n for v in classification['groups'].values() for n in v};aliases=classification['aliases'];high=set(classification['groups']['alta_tecnologia']);lookup={(str(r['r']),str(r['a']),r['p'].replace('.','')):r for r in overview['rows']}
records=[]
for j,i in enumerate(te):
 r=rows[i];o=lookup.get((r['Rodada'],str(r['NumeroArea']),r['ProcessoMinerario'].replace('.','')),{});minerals={names[t] for t in {aliases.get(norm(t),norm(t)) for t in o.get('sub','').split(';')} if t in names}
 records.append({'processo':r['ProcessoMinerario'],'area':r['NumeroArea'],'uf':sets['basico'][i]['uf'],'substancias':o.get('sub',''),'estrategico':bool(minerals),'alta_tecnologia':bool(minerals&high),'observed':int(y[i]),'prob':probs[chosen][j].round(7).tolist(),'reference':probs['uf'][j].round(7).tolist()})
report['subgroups']={}
for g in ['estrategico','alta_tecnologia']:
 ix=np.array([j for j,r in enumerate(records) if r[g]],dtype=int);report['subgroups'][g]={'selected':metrics(y[te[ix]],probs[chosen][ix]),'uf':metrics(y[te[ix]],probs['uf'][ix])}
(O/'experimento_ml_v5.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(O/'predicoes_v5.json').write_text(json.dumps(records,ensure_ascii=False,separators=(',',':')),encoding='utf8')
print('COMPLETE',chosen,report['paired_bootstrap_vs_uf_ci95'],flush=True)
