"""Finite retrospective utility experiments. See protocolo_v4.md before running."""
import os
os.environ['OMP_NUM_THREADS']='4'
os.environ['OPENBLAS_NUM_THREADS']='4'
import pathlib,sys,json,gzip,datetime,hashlib,collections,copy
p=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(p/'ml_deps'))
sys.path.insert(0,str(p/'ml_v4'))
import numpy as np,joblib,sklearn
from sklearn.feature_extraction import DictVectorizer
from sklearn.ensemble import HistGradientBoostingClassifier,ExtraTreesClassifier,ExtraTreesRegressor
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score,average_precision_score,silhouette_score,adjusted_rand_score,mean_absolute_error,r2_score
out=p
z=json.load(gzip.open(out/'experimento_v3_congelado.json.gz','rt',encoding='utf-8'))
rows=z['rows'];sets=z['sets'];rounds=np.array([int(r['Rodada']) for r in rows]);bid=np.array([r['bid'] for r in rows]);positive=np.array([r['target'] for r in rows]);free=np.array([r['Situacao']=='Livre' for r in rows],int)
def proc(s):return s.replace('.','').strip()
names=json.loads((out/'dicionario_eventos.json').read_text(encoding='utf-8'))
hist={}
with gzip.open(out/'trajetorias_processos.jsonl.gz','rt',encoding='utf-8') as f:
    for line in f:
        r=json.loads(line);hist[proc(r['processo'])]=r['eventos_registrados']
sets['marcos']=[]
audit=collections.Counter()
for i,r in enumerate(rows):
    f=dict(sets['trajetoria'][i]);cut=r['cutoff'];ev=[e for e in hist.get(proc(r['ProcessoMinerario']),[]) if e['data'] and e['data']<cut]
    markers=sorted(e['data'] for e in ev if e['codigo'] in ['2275','328','329'])
    f['marco_disponibilidade_observado']=int(bool(markers));f['marcos_disponibilidade_n']=len(markers)
    f['dias_desde_primeiro_marco']=-1;f['dias_desde_ultimo_marco']=-1;f['contexto_anterior_marco']='sem_marco'
    if markers:
        audit['linhas_com_marco']+=1;dt=datetime.date.fromisoformat(cut)
        f['dias_desde_primeiro_marco']=(dt-datetime.date.fromisoformat(markers[0])).days
        f['dias_desde_ultimo_marco']=(dt-datetime.date.fromisoformat(markers[-1])).days
        before=[e for e in ev if e['data']<markers[-1] and not names.get(e['codigo'],'').startswith(('DISP','APTO'))]
        if before:
            last=max(e['data'] for e in before);contexts={' '.join(names.get(e['codigo'],'DESCONHECIDO').split()[:2]) for e in before if e['data']==last}
            f['contexto_anterior_marco']=next(iter(contexts)) if len(contexts)==1 else 'ambiguo_no_dia'
        else:f['contexto_anterior_marco']='sem_contexto'
    sets['marcos'].append(f)
def split(rr,rd):
    te=np.where(rounds==rd)[0];keys={rows[i]['ProcessoMinerario'] for i in te}
    return np.array([i for i in range(len(rows)) if rounds[i] in rr and rows[i]['ProcessoMinerario'] not in keys]),te
def rank_metrics(y,s):
    n=int(np.ceil(len(y)*.2));ix=np.argsort(-s,kind='stable')[:n];prec=float(y[ix].mean());base=float(y.mean())
    return {'n':len(y),'reviewed':n,'captured':int(y[ix].sum()),'precision20':prec,'recall20':float(y[ix].sum()/y.sum()),'prevalence':base,'lift20':prec/base,'auc':float(roc_auc_score(y,s)),'average_precision':float(average_precision_score(y,s))}
def predict(key,tr,te,y):
    if key=='regra_area':return np.array([sets['basico'][i]['log_hectares'] for i in te]),None
    if key=='frequencia_uf':
        groups=collections.defaultdict(list)
        for i in tr:groups[sets['basico'][i].get('uf','')].append(y[i])
        # Add 20 pooled pseudo-observations to reduce small-state volatility.
        scores={k:(sum(v)+20*y[tr].mean())/(len(v)+20) for k,v in groups.items()}
        return np.array([scores.get(sets['basico'][i].get('uf',''),y[tr].mean()) for i in te]),None
    kind,fs=key.split('_',1);v=DictVectorizer(sparse=False);a=v.fit_transform([sets[fs][i] for i in tr]);b=v.transform([sets[fs][i] for i in te])
    m=HistGradientBoostingClassifier(max_iter=150,max_leaf_nodes=15,l2_regularization=10,random_state=42) if kind=='hgb' else ExtraTreesClassifier(n_estimators=180,max_depth=16,min_samples_leaf=15,max_features=.8,n_jobs=4,random_state=42)
    m.fit(a,y[tr]);return m.predict_proba(b)[:,1],(v,m)
report={'version':'4','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sklearn':sklearn.__version__,'protocol_sha256':hashlib.sha256((p/'protocolo_v4.md').read_bytes()).hexdigest(),'audit':dict(audit),'ranking':{},'regression':{},'clustering':{},'limitations':['Retrospectivo: rodada8 ja examinada.','Cortes anuais conservadores; contexto de evento nao certifica fase juridica.','Atributos atuais sujeitos a revisoes; nao ha snapshots historicos.','Clusters sao perfis administrativos, nao depositos geologicos ou tipos naturais.']}
def save(): (out/'experimento_ml_v4.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
keys=['hgb_basico','hgb_trajetoria','hgb_marcos','extra_marcos','frequencia_uf','regra_area'];saved={};predictions={}
for target,y in [('lance_positivo',positive),('livre',free)]:
    d={'validation':{}}
    for rr,rd in [([1,2],4),([1,2,3],5)]:
        tr,te=split(rr,rd);d['validation'][str(rd)]={}
        for key in keys:
            score,_=predict(key,tr,te,y);d['validation'][str(rd)][key]=rank_metrics(y[te],score)
        print(target,'validation',rd,d['validation'][str(rd)],flush=True)
    avg={k:float(np.mean([d['validation'][str(rd)][k]['lift20'] for rd in [4,5]])) for k in keys}
    chosen=max(avg,key=avg.get);d['selection_lift20']=avg;d['chosen']=chosen
    tr,te=split([1,2,3,4,5],8);score,model=predict(chosen,tr,te,y);saved[target]=model;d['test']=rank_metrics(y[te],score)
    d['test_references']={}
    for k in ['frequencia_uf','regra_area']:
        sc,_=predict(k,tr,te,y);d['test_references'][k]=rank_metrics(y[te],sc)
    top=np.zeros(len(te),bool);top[np.argsort(-score,kind='stable')[:int(np.ceil(len(te)*.2))]]=True
    groups=collections.defaultdict(list)
    for j,i in enumerate(te):groups[rows[i]['ProcessoMinerario']].append(j)
    groups=list(groups.values());rng=np.random.default_rng(42);delta=[]
    for _ in range(400):
        jj=np.concatenate([groups[k] for k in rng.integers(len(groups),size=len(groups))]);sel=top[jj]
        delta.append(float(y[te[jj]][sel].mean()-y[te[jj]].mean()))
    d['precision_minus_random_ci95']=np.quantile(delta,[.025,.975]).tolist()
    d['passes_lift_threshold']=bool(all(d['validation'][str(rd)][chosen]['lift20']>1.1 for rd in [4,5]) and d['test']['lift20']>1.1)
    predictions[target]=[{'processo':rows[i]['ProcessoMinerario'],'area':rows[i]['NumeroArea'],'score':float(score[j]),'observed':int(y[i])} for j,i in enumerate(te)]
    report['ranking'][target]=d;save();print('RANK FINAL',target,d['chosen'],d['test'],flush=True)
def regress(fs,tr,te):
    tr=tr[positive[tr]==1];te=te[positive[te]==1];v=DictVectorizer(sparse=False);a=v.fit_transform([sets[fs][i] for i in tr]);b=v.transform([sets[fs][i] for i in te])
    m=ExtraTreesRegressor(n_estimators=180,max_depth=16,min_samples_leaf=12,max_features=.8,n_jobs=4,random_state=42);m.fit(a,np.log1p(bid[tr]));pred=np.maximum(0,np.expm1(m.predict(b)))
    return {'rmsle':float(np.sqrt(np.mean((np.log1p(pred)-np.log1p(bid[te]))**2))),'mae':float(mean_absolute_error(bid[te],pred)),'r2':float(r2_score(bid[te],pred))}
for rd,rr in [(4,[1,2]),(5,[1,2,3])]:
    tr,te=split(rr,rd);report['regression'][str(rd)]={fs:regress(fs,tr,te) for fs in ['trajetoria','marcos']};save()
chosen=min(['trajetoria','marcos'],key=lambda fs:np.mean([report['regression'][str(rd)][fs]['rmsle'] for rd in [4,5]]))
tr,te=split([1,2,3,4,5],8);report['regression']['chosen']=chosen;report['regression']['test']=regress(chosen,tr,te);save();print('REG',report['regression'],flush=True)
# Fit administrative profiles once per process; outcomes never enter clustering.
latest={}
for i in tr:
    key=rows[i]['ProcessoMinerario']
    if key not in latest or rounds[i]>rounds[latest[key]]:latest[key]=i
ci=np.array(list(latest.values()));dims=['log_hectares','idade_processo_no_corte','eventos_tipos_distintos','dias_observados','historico_amplitude_dias','intervalo_mediano_dias','eventos_ultimos_365','documentos_anteriores','associacoes_anteriores','titulos_vencidos_no_corte']
raw=np.array([[float(sets['trajetoria'][i].get(k,0)) for k in dims] for i in range(len(rows))]);x=raw.copy();x[:,1:]=np.log1p(np.maximum(0,x[:,1:]));scaler=StandardScaler().fit(x[ci]);a=scaler.transform(x[ci]);b=scaler.transform(x[te]);rng=np.random.default_rng(42)
def cluster(kind,k,seed):
    return KMeans(n_clusters=k,n_init=10,random_state=seed) if kind=='kmeans' else GaussianMixture(n_components=k,covariance_type='diag',n_init=3,reg_covar=1e-4,random_state=seed,max_iter=200)
candidates={};models={}
for kind in ['kmeans','gmm']:
    for k in [3,5,8]:
        name=f'{kind}_{k}';m=cluster(kind,k,42).fit(a);lab=m.predict(a);sizes=np.bincount(lab,minlength=k);sil=float(silhouette_score(a,lab,sample_size=min(1500,len(a)),random_state=42));aris=[]
        for seed in [11,22,33,44,55]:
            sample=np.random.default_rng(seed).choice(len(a),int(.8*len(a)),replace=False);other=cluster(kind,k,seed).fit(a[sample]);aris.append(float(adjusted_rand_score(lab,other.predict(a))))
        candidates[name]={'silhouette':sil,'stability_ari_mean':float(np.mean(aris)),'stability_ari_values':aris,'smallest_fraction':float(sizes.min()/len(a)),'converged':bool(getattr(m,'converged_',True))};models[name]=m;print('CLUSTER',name,candidates[name],flush=True)
eligible=[k for k,v in candidates.items() if v['silhouette']>=.2 and v['stability_ari_mean']>=.75 and v['smallest_fraction']>=.03 and v['converged']]
chosen=max(eligible,key=lambda k:candidates[k]['silhouette']) if eligible else None
d={'features':dims,'train_processes':len(ci),'candidates':candidates,'chosen':chosen,'passes_quality_threshold':bool(eligible)}
if chosen:
    m=models[chosen];lab=m.predict(a);testlab=m.predict(b);profiles=[]
    for k in range(int(chosen.split('_')[1])):
        ii=ci[lab==k];jj=te[testlab==k]
        profiles.append({'cluster':k+1,'train_n':len(ii),'test_n':len(jj),'train_medians':{f:float(np.median(raw[ii,c])) for c,f in enumerate(dims)},'train_positive_rate':float(positive[ii].mean()),'test_positive_rate':float(positive[jj].mean()) if len(jj) else None,'test_free_rate':float(free[jj].mean()) if len(jj) else None})
    d['profiles']=profiles;saved['clusters']=(scaler,m,dims)
    predictions['clusters']=[{'processo':rows[i]['ProcessoMinerario'],'area':rows[i]['NumeroArea'],'cluster':int(testlab[j])+1} for j,i in enumerate(te)]
report['clustering']=d;save();joblib.dump(saved,p/'models_v4.joblib')
(out/'predicoes_v4.json').write_text(json.dumps(predictions,ensure_ascii=False),encoding='utf-8')
with gzip.open(out/'experimento_v4_congelado.json.gz','wt',encoding='utf-8') as f:json.dump({'rows':rows,'sets':sets},f,ensure_ascii=False)
print('COMPLETE',json.dumps(report,ensure_ascii=False),flush=True)
