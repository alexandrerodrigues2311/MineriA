"""Post-selection audit: no model refitting or changing chosen models."""
import pathlib,sys,json,gzip,collections,csv,hashlib
p=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(p/'ml_v4'))
import numpy as np
o=p;z=json.load(gzip.open(o/'experimento_v4_congelado.json.gz','rt',encoding='utf-8'));rows=z['rows'];sets=z['sets'];report=json.loads((o/'experimento_ml_v4.json').read_text(encoding='utf-8'));pred=json.loads((o/'predicoes_v4.json').read_text(encoding='utf-8'))
rounds=np.array([int(r['Rodada']) for r in rows]);te=np.where(rounds==8)[0];testkeys={rows[i]['ProcessoMinerario'] for i in te};tr=np.array([i for i in range(len(rows)) if rounds[i]<8 and rows[i]['ProcessoMinerario'] not in testkeys]);assert not testkeys.intersection(rows[i]['ProcessoMinerario'] for i in tr)
def expected_precision(y,s):
 n=int(np.ceil(.2*len(y)));threshold=np.sort(s)[-n];above=s>threshold;ties=s==threshold;slots=n-int(above.sum());return float((y[above].sum()+slots*y[ties].mean())/n)
audit={'note':'Auditoria posterior a selecao, sem trocar modelos. Regra de menor area e sensibilidade de empates acrescentadas como referencias, nao como novos candidatos.','train_n':len(tr),'test_n':len(te),'disjoint_processes':True,'ranking':{}}
for target in ['lance_positivo','livre']:
 y=np.array([r['target'] if target=='lance_positivo' else int(r['Situacao']=='Livre') for r in rows]);g=collections.defaultdict(list)
 for i in tr:g[sets['basico'][i]['uf']].append(y[i])
 rates={k:(sum(v)+20*y[tr].mean())/(len(v)+20) for k,v in g.items()};uf=np.array([rates.get(sets['basico'][i]['uf'],y[tr].mean()) for i in te]);area=np.array([sets['basico'][i]['log_hectares'] for i in te]);score=np.array([r['score'] for r in pred[target]])
 assert len(score)==len(te)
 audit['ranking'][target]={k:expected_precision(y[te],s) for k,s in [('model_ties_random',score),('uf_ties_random',uf),('large_area_ties_random',area),('small_area_ties_random',-area)]}
 order=np.argsort(-score,kind='stable')
 with (o/f'fila_v4_{target}.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f,delimiter=';');w.writerow(['ordem','processo','area','pontuacao_nao_calibrada','resultado_historico','rodada'])
  for rank,j in enumerate(order,1):
   r=pred[target][j];num,year=r['processo'].replace('.','').split('/');num=num.zfill(6);w.writerow([rank,num[:3]+'.'+num[3:]+'/'+year,r['area'],r['score'],r['observed'],8])
if 'clusters' in pred:
 with (o/'perfis_v4_areas.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f,delimiter=';');w.writerow(['processo','area','perfil','rodada'])
  for r in pred['clusters']:
   num,year=r['processo'].replace('.','').split('/');num=num.zfill(6);w.writerow([num[:3]+'.'+num[3:]+'/'+year,r['area'],r['cluster'],8])
(o/'auditoria_v4.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(audit,ensure_ascii=False,indent=2))
