# Reprodução V4

Python 3.12. Instale requirements.txt em ambiente isolado. Execute python reproduzir.py nesta pasta; a execução sobrescreve os relatórios, preserve uma cópia. Os históricos derivados são registros públicos sem nomes/documentos de participantes. Parâmetros, cortes e limitações estão no protocolo. O pacote local não equivale a depósito público permanente. Código original sob MIT; dados ANM sujeitos aos termos das fontes.
