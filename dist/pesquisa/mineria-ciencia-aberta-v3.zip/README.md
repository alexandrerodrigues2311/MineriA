# MinerIA V3 — estudo retrospectivo reproduzível

Python 3.12.14. Instale requirements.txt num ambiente isolado e execute `python reproduzir.py` nesta pasta. A execução refaz seis configurações em duas validações, seleção, ajuste final, bootstrap por processo, permutações e modelo multiclasse. Pode levar vários minutos. Os JSON de resultado serão sobrescritos; preserve cópia para comparação. O protocolo foi fixado antes dos ajustes V3, depois de a rodada 8 já ter sido analisada em estudos anteriores. Isso não é pré-registro independente.

`experimento_v3_congelado.json.gz` contém atributos derivados e resultados de 21.175 observações; não contém nomes ou documentos de pessoas. `trajetorias_processos.jsonl.gz` conserva eventos por código, fases sem nomes/documentos de vencedores e associações, sem observações livres. O dicionário permite interpretar códigos. Fontes: https://dadosabertos.anm.gov.br/SOPLE/ e https://dadosabertos.anm.gov.br/SCM/ (extração setembro de 2026).

O script reconstruct_v3.py documenta a construção original, mas depende dos CSV do Cadastro Mineiro e de features_v2.joblib do pipeline anterior. A reprodução dos resultados V3 é autônoma por meio do conjunto congelado; para reconstruir da origem, use também o pacote V2 e as fontes identificadas. Os arquivos brutos volumosos não estão duplicados neste ZIP. Hashes verificam integridade, não autenticidade da fonte.

Todos os modelos são supervisionados. Lance consolidado não é pagamento. Importância preditiva não é causalidade. O conjunto 8 foi reutilizado e não é uma validação prospectiva. Não use para determinar lances individuais ou receita orçamentária. O artefato permanece experimental.

Código original deste pacote: permissão de uso, estudo, modificação e redistribuição sob licença MIT, sem garantia. Dados de terceiros mantêm seus próprios termos; consulte o catálogo ANM. A entrega privada para revisão não constitui depósito público persistente nem validação independente.
