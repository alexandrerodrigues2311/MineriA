"""Reconstruct administrative histories, preserving observable evidence, not legal states."""
import pathlib,sys,csv,json,collections,datetime,math,gzip,hashlib
p=pathlib.Path(__file__).parent;sys.path.insert(0,str(p/'ml_deps'))
import joblib,numpy as np
out=p.parent/'outputs';q=p/'scm_sople'
def read(n):return csv.DictReader((q/(n+'.csv')).open(encoding='utf-8-sig'),delimiter=';')
def key(s):return s.replace('.','').strip()
def ds(s):
    a,b=key(s).split('/');a=a.zfill(6);return a[:3]+'.'+a[3:]+'/'+b
z=joblib.load(p/'features_v2.joblib');rows=z['final'];keys={r['ProcessoMinerario'] for r in rows}
raw=list(csv.DictReader((p/'ResultadoRodadaDisponibilidade.csv').open(encoding='utf-8-sig'),delimiter=';'))
social=list(csv.DictReader((p/'ResultadoAvaliacaoSocial.csv').open(encoding='utf-8-sig'),delimiter=';'))
allkeys={key(r['ProcessoMinerario']) for r in raw+social};names={r['IDEvento']:r['DSEvento'] for r in read('Evento')}
tables={}
for n in ['ProcessoEvento','ProcessoTitulo','ProcessoSubstancia','ProcessoPessoa','ProcessoAssociacao','ProcessoDocumentacao']:
    t=collections.defaultdict(list)
    for r in read(n):
        if key(r['DSProcesso']) in allkeys:t[key(r['DSProcesso'])].append(r)
    tables[n]=t
    print(n,sum(map(len,t.values())),flush=True)
features=[];audit=collections.Counter();transitions=collections.Counter();summaries=[]
for proc in sorted(allkeys):
    ev=sorted(tables['ProcessoEvento'][proc],key=lambda e:(e['DTEvento'],e['IDEvento']))
    # Consecutive distinct date groups: do not assert intraday ordering.
    dated=collections.defaultdict(set)
    for e in ev:
        if e['DTEvento']:dated[e['DTEvento']].add(e['IDEvento'])
    days=sorted(dated)
    for a,b in zip(days,days[1:]):
        if len(dated[a])==len(dated[b])==1:transitions[(next(iter(dated[a])),next(iter(dated[b])))]+=1
    histories=[r for r in raw+social if key(r['ProcessoMinerario'])==proc] if False else []
    summaries.append({'processo':ds(proc),'eventos':len(ev),'datas_distintas':len(days),'primeiro_evento':days[0] if days else None,'ultimo_evento':days[-1] if days else None,'associacoes_disponibilidade':sum(e['IDTipoAssociacao']=='8' for e in tables['ProcessoAssociacao'][proc])})
phases=collections.defaultdict(list)
for r in raw+social:phases[key(r['ProcessoMinerario'])].append({k:v for k,v in r.items() if k not in ['NomeVencedor','CpfCnpjVencedor']})
with gzip.open(out/'trajetorias_processos.jsonl.gz','wt',encoding='utf-8') as f:
    for s in summaries:
        proc=key(s['processo']);s['rodadas']=sorted({int(r['Rodada']) for r in phases[proc]});s['fases_sople']=phases[proc]
        s['eventos_registrados']=[{'data':e['DTEvento'],'codigo':e['IDEvento']} for e in sorted(tables['ProcessoEvento'][proc],key=lambda e:(e['DTEvento'],e['IDEvento']))]
        # Free text deliberately excluded: it may contain personal data.
        s['associacoes']=[{k:v for k,v in e.items() if k not in ['DSProcesso','OBAssociacao']} for e in tables['ProcessoAssociacao'][proc]]
        f.write(json.dumps(s,ensure_ascii=False)+'\n')
for r,base in zip(rows,z['sets']['historico']):
    proc=r['ProcessoMinerario'];cut=r['cutoff'];d=datetime.date.fromisoformat(cut);f=dict(base)
    ev=[e for e in tables['ProcessoEvento'][proc] if e['DTEvento'] and e['DTEvento']<cut]
    dates=sorted({e['DTEvento'] for e in ev});ords=[datetime.date.fromisoformat(x).toordinal() for x in dates]
    gaps=np.diff(ords)
    f.update(eventos_tipos_distintos=len({e['IDEvento'] for e in ev}),dias_observados=len(dates),historico_amplitude_dias=(ords[-1]-ords[0]) if ords else 0,intervalo_mediano_dias=float(np.median(gaps)) if len(gaps) else 0,intervalo_maximo_dias=int(max(gaps)) if len(gaps) else 0,idade_processo_no_corte=int(cut[:4])-int(proc.split('/')[1]))
    for n in [90,365,1095]:f['eventos_ultimos_'+str(n)]=sum(0<(d-datetime.date.fromisoformat(e['DTEvento'])).days<=n for e in ev)
    f['ultimo_tipo_evento']=ev and sorted(ev,key=lambda e:(e['DTEvento'],e['IDEvento']))[-1]['IDEvento'] or 'ausente'
    # Last type has ambiguous ties; explicitly suppress category when last date has >1 type.
    if dates and len({e['IDEvento'] for e in ev if e['DTEvento']==dates[-1]})>1:f['ultimo_tipo_evento']='multiplos_no_dia'
    for family,token in [('exigencia','EXIG'),('arquivamento','ARQUIV'),('disponibilidade','DISPONIB'),('pesquisa','PESQ'),('lavra','LAVRA')]:
        f['familia_'+family]=sum(token in names.get(e['IDEvento'],'') for e in ev)
    for table,date,tag in [('ProcessoDocumentacao','DTProtocolo','documentos'),('ProcessoAssociacao','DTAssociacao','associacoes')]:
        rr=[e for e in tables[table][proc] if e[date] and e[date]<cut];f[tag+'_anteriores']=len(rr)
        f[tag+'_ultimo_ano']=sum(0<(d-datetime.date.fromisoformat(e[date])).days<=365 for e in rr)
    people=[e for e in tables['ProcessoPessoa'][proc] if e['IDTipoRelacao']=='1' and e['DTInicioVigencia'] and e['DTInicioVigencia']<cut]
    f['titulares_vigentes_no_corte']=len({e['IDPessoa'] for e in people if not e['DTFimVigencia'] or e['DTFimVigencia']>=cut})
    f['vinculos_titular_encerrados']=sum(bool(e['DTFimVigencia']) and e['DTFimVigencia']<cut for e in people)
    f['titulos_vencidos_no_corte']=sum(bool(e['DTPublicacao']) and e['DTPublicacao']<cut and bool(e['DTVencimento']) and e['DTVencimento']<cut for e in tables['ProcessoTitulo'][proc])
    features.append(f);audit['eventos_usados_linhas_area_rodada']+=len(ev)
    audit['eventos_excluidos_futuros_linhas_area_rodada']+=sum(e['DTEvento']>=cut for e in tables['ProcessoEvento'][proc])
report={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processos':len(allkeys),'linhas_fases':len(raw)+len(social),'processos_reofertados':sum(len(s['rodadas'])>1 for s in summaries),'eventos':sum(len(tables['ProcessoEvento'][k]) for k in allkeys),'sem_evento':sum(not tables['ProcessoEvento'][k] for k in allkeys),'relacoes_participante_tipo12':sum(e['IDTipoRelacao']=='12' for rr in tables['ProcessoPessoa'].values() for e in rr),'associacoes_disponibilidade':sum(e['IDTipoAssociacao']=='8' for rr in tables['ProcessoAssociacao'].values() for e in rr),'audit':dict(audit),'transicoes_mais_frequentes':[{'de':names.get(a,a),'para':names.get(b,b),'n':n} for (a,b),n in transitions.most_common(20)],'limitations':['Eventos nao equivalem automaticamente a estados juridicos.','Ausencia de evento nao prova ausencia de atividade.','Associacao tipo8 nao comprova pagamento nem inicio de lavra.','Datas filtradas em extracao atual nao comprovam disponibilidade publica passada.','Poligonal e municipio atuais nao reconstituem necessariamente a geometria da oferta.']}
z['sets']['trajetoria']=features;joblib.dump(z,p/'features_v3.joblib')
(out/'reconstrucao_trajetorias.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'dicionario_eventos.json').write_text(json.dumps(names,ensure_ascii=False),encoding='utf-8')
with gzip.open(out/'experimento_v3_congelado.json.gz','wt',encoding='utf-8') as f:json.dump({'rows':[{k:r[k] for k in ['Rodada','NumeroArea','ProcessoMinerario','Situacao','target','bid','cutoff']} for r in rows],'sets':{k:z['sets'][k] for k in ['basico','historico','trajetoria']}},f,ensure_ascii=False)
print(json.dumps(report,ensure_ascii=False,indent=2))
