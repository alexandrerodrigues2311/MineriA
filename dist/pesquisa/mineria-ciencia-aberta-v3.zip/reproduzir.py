"""Run the fixed retrospective protocol; frozen public features suffice to reproduce."""
import os
os.environ.setdefault('OMP_NUM_THREADS','4');os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
import pathlib,sys,json,gzip,datetime,hashlib
p=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(p/'ml_deps'))
import numpy as np,joblib,sklearn
from sklearn.feature_extraction import DictVectorizer
from sklearn.ensemble import RandomForestClassifier,RandomForestRegressor,ExtraTreesClassifier,ExtraTreesRegressor,HistGradientBoostingClassifier,HistGradientBoostingRegressor
from sklearn.linear_model import LogisticRegression,Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score,brier_score_loss,average_precision_score,log_loss,mean_absolute_error,median_absolute_error,r2_score,balanced_accuracy_score,confusion_matrix
out=p;out.mkdir(exist_ok=True)
z=json.load(gzip.open(out/'experimento_v3_congelado.json.gz','rt',encoding='utf-8'));rows=z['rows'];sets=z['sets'];y=np.array([r['target'] for r in rows]);bid=np.array([r['bid'] for r in rows]);rounds=np.array([int(r['Rodada']) for r in rows])
def split(rr,rd):
    te=np.where(rounds==rd)[0];keys={rows[i]['ProcessoMinerario'] for i in te};tr=np.array([i for i in range(len(rows)) if rounds[i] in rr and rows[i]['ProcessoMinerario'] not in keys]);return tr,te
def models(k):
    if k=='rf':return RandomForestClassifier(n_estimators=180,max_depth=12,min_samples_leaf=20,max_features=.7,n_jobs=4,random_state=42),RandomForestRegressor(n_estimators=180,max_depth=12,min_samples_leaf=12,max_features=.7,n_jobs=4,random_state=42)
    if k=='extra':return ExtraTreesClassifier(n_estimators=180,max_depth=16,min_samples_leaf=15,max_features=.8,n_jobs=4,random_state=42),ExtraTreesRegressor(n_estimators=180,max_depth=16,min_samples_leaf=12,max_features=.8,n_jobs=4,random_state=42)
    if k=='hgb':return HistGradientBoostingClassifier(max_iter=150,max_leaf_nodes=15,l2_regularization=10,random_state=42),HistGradientBoostingRegressor(max_iter=150,max_leaf_nodes=15,l2_regularization=10,random_state=42)
    return make_pipeline(StandardScaler(),LogisticRegression(C=.1,max_iter=1500)),make_pipeline(StandardScaler(),Ridge(alpha=100))
def metrics(te,prob,pred):
    pos=y[te]==1;logerr=np.log1p(pred[pos])-np.log1p(bid[te][pos]);return {'auc':float(roc_auc_score(y[te],prob)),'brier':float(brier_score_loss(y[te],prob)),'average_precision':float(average_precision_score(y[te],prob)),'log_loss':float(log_loss(y[te],prob)),'rmsle':float(np.sqrt(np.mean(logerr**2))),'mae_reais':float(mean_absolute_error(bid[te][pos],pred[pos])),'mediana_erro_absoluto_reais':float(median_absolute_error(bid[te][pos],pred[pos])),'r2_reais':float(r2_score(bid[te][pos],pred[pos]))}
def fit(key,tr,te):
    kind,fs=key.split('_',1);v=DictVectorizer(sparse=False);a=v.fit_transform([sets[fs][i] for i in tr]);b=v.transform([sets[fs][i] for i in te]);c,g=models(kind);c.fit(a,y[tr]);g.fit(a[y[tr]==1],np.log1p(bid[tr][y[tr]==1]));return v,c,g,c.predict_proba(b)[:,1],np.maximum(0,np.expm1(g.predict(b)))
candidates=['hgb_basico','hgb_historico','hgb_trajetoria','rf_trajetoria','extra_trajetoria','linear_trajetoria']
report={'version':'3','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sklearn':sklearn.__version__,'protocol_sha256':hashlib.sha256((p/'protocolo_v3.md').read_bytes()).hexdigest(),'status':'retrospective_not_production','validation':{},'selection':{},'limitations':['Rodada8 ja examinada anteriormente; nao e teste prospectivo intocado.','Extracao atual e cortes anuais conservadores; vintages publicos nao disponiveis.','Lances consolidados nominais, nao pagamento ou receita realizada.','Bootstrap por processo dentro de8 nao mede variacao entre rodadas.','Importancia por permutacao nao e significancia estatistica nem efeito causal.']}
for name,rr,rd in [('rodada4',[1,2],4),('rodada5',[1,2,3],5)]:
    tr,te=split(rr,rd);d={'train_rounds':rr,'test_round':rd,'train_n':len(tr),'test_n':len(te),'baseline':metrics(te,np.full(len(te),y[tr].mean()),np.full(len(te),np.median(bid[tr][y[tr]==1]))),'models':{}}
    for key in candidates:
        v,c,g,prob,pred=fit(key,tr,te);d['models'][key]=metrics(te,prob,pred);print(name,key,d['models'][key],flush=True)
    report['validation'][name]=d
    (out/'experimento_ml_v3_parcial.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
for key in candidates:report['selection'][key]={m:float(np.mean([d['models'][key][m] for d in report['validation'].values()])) for m in ['brier','rmsle']}
cc=min(candidates,key=lambda k:report['selection'][k]['brier']);cr=min(candidates,key=lambda k:report['selection'][k]['rmsle']);report['chosen']={'classifier':cc,'regressor':cr}
tr,te=split([1,2,3,4,5],8);saved={};cache={}
for key in set([cc,cr]):cache[key]=fit(key,tr,te)
vc,c,_,prob,_=cache[cc];vr,_,g,_,pred=cache[cr];saved={'classifier':(vc,c),'regressor':(vr,g)}
baselineprob=np.full(len(te),y[tr].mean());baselinepred=np.full(len(te),np.median(bid[tr][y[tr]==1]));report['test']={'train_n':len(tr),'test_n':len(te),'train_positive':int(y[tr].sum()),'test_positive':int(y[te].sum()),'train_rounds':[1,2,3,4,5],'test_round':8,'model':metrics(te,prob,pred),'baseline':metrics(te,baselineprob,baselinepred)}
print('TEST',report['chosen'],report['test'],flush=True)
# Paired cluster bootstrap by process; retain multiplicity for repeated areas of a process.
clusters={}
for j,i in enumerate(te):clusters.setdefault(rows[i]['ProcessoMinerario'],[]).append(j)
clusters=list(clusters.values());rng=np.random.default_rng(42);boots=[]
for _ in range(400):
    jj=np.concatenate([clusters[k] for k in rng.integers(0,len(clusters),len(clusters))]);ix=te[jj];mm=metrics(ix,prob[jj],pred[jj]);bb=metrics(ix,baselineprob[jj],baselinepred[jj]);boots.append([mm['auc'],mm['brier']-bb['brier'],mm['rmsle']-bb['rmsle'],mm['mae_reais']-bb['mae_reais']])
report['bootstrap_process_400']={k:np.quantile(np.array(boots)[:,j],[.025,.975]).tolist() for j,k in enumerate(['auc','delta_brier','delta_rmsle','delta_mae'])}
report['calibration']=[]
for lower in np.arange(0,1,.1):
    mask=(prob>=lower)&(prob<lower+.1+1e-12)
    if mask.any():report['calibration'].append({'from':round(float(lower),1),'n':int(mask.sum()),'predicted':float(prob[mask].mean()),'observed':float(y[te][mask].mean())})
report['triage']=[]
order=np.argsort(-prob,kind='stable')
for fraction in [.1,.2,.5,1]:
    n=int(np.ceil(len(te)*fraction));jj=order[:n];report['triage'].append({'fraction':fraction,'n_reviewed':n,'arrematadas_capturadas':int(y[te][jj].sum()),'precision':float(y[te][jj].mean()),'recall':float(y[te][jj].sum()/y[te].sum()),'baseline_random_expected':float(y[te].mean()*n)})
# Permute whole semantic groups, preserving one-hot categories within each group.
def groupname(s):
    if s.startswith(('uf=','regime=')):return s.split('=')[0]
    if s in ['log_hectares','ano_processo']:return s
    if s.startswith('substancia'):return 'substancias'
    if s.startswith(('titulo','titulos_')):return 'titulos'
    if s.startswith(('requerentes_','titulares_','vinculos_')):return 'titularidade'
    if s.startswith(('documentos','associacoes')):return s.split('_')[0]
    if s.startswith('evento_'):return 'tipos_eventos'
    return 'dinamica_administrativa'
report['permutation_groups']={}
for task,v,model,fs in [('classifier',vc,c,cc.split('_',1)[1]),('regressor',vr,g,cr.split('_',1)[1])]:
    inds=te if task=='classifier' else te[y[te]==1];a=v.transform([sets[fs][i] for i in inds]);gg={}
    for j,s in enumerate(v.feature_names_):gg.setdefault(groupname(s),[]).append(j)
    def loss(mat):return brier_score_loss(y[inds],model.predict_proba(mat)[:,1]) if task=='classifier' else np.sqrt(np.mean((np.log1p(bid[inds])-model.predict(mat))**2))
    base=loss(a);res=[]
    for name,cols in gg.items():
        values=[]
        for repeat in range(5):
            b=a.copy();perm=rng.permutation(len(b));b[:,cols]=a[perm][:,cols];values.append(float(loss(b)-base))
        res.append({'group':name,'mean_loss_increase':float(np.mean(values)),'sd':float(np.std(values))})
    report['permutation_groups'][task]=sorted(res,key=lambda r:-r['mean_loss_increase'])
classes=['Arrematada','Conquistada','Livre'];ym=np.array([classes.index(r['Situacao']) for r in rows]);v=DictVectorizer(sparse=False);a=v.fit_transform([sets['trajetoria'][i] for i in tr]);b=v.transform([sets['trajetoria'][i] for i in te]);m,_=models('hgb');m.fit(a,ym[tr]);mp=m.predict_proba(b);mh=m.predict(b);base=np.tile(np.bincount(ym[tr],minlength=3)/len(tr),(len(te),1));report['multiclass']={'classes':classes,'log_loss':float(log_loss(ym[te],mp)),'baseline_log_loss':float(log_loss(ym[te],base)),'balanced_accuracy':float(balanced_accuracy_score(ym[te],mh)),'confusion_matrix':confusion_matrix(ym[te],mh).tolist(),'model':'hgb_trajetoria_fixed_secondary'};saved['multiclass']=(v,m)
joblib.dump(saved,p/'models_v3.joblib');(out/'experimento_ml_v3.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
pr=[{'processo':rows[i]['ProcessoMinerario'],'area':rows[i]['NumeroArea'],'p':float(prob[j]),'value':float(pred[j]),'observed':rows[i]['Situacao'],'bid':float(bid[i])} for j,i in enumerate(te)]
(out/'predicoes_v3_retrospectivas.json').write_text(json.dumps(pr,ensure_ascii=False),encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
