import pathlib,sys,zipfile,csv,json,collections
p=pathlib.Path(__file__).parent;sys.path.insert(0,str(p/'geo_deps'));import shapefile
keys={r['ProcessoMinerario'] for r in csv.DictReader((p/'ResultadoRodadaDisponibilidade.csv').open(encoding='utf-8-sig'),delimiter=';')}; boxes={}
for filename in ['BRASIL.zip','PROCESSOS_INATIVOS.zip']:
    z=zipfile.ZipFile(p/filename); dest=p/'geometry'/filename[:-4];dest.mkdir(parents=True,exist_ok=True)
    for n in z.namelist():
        if pathlib.Path(n).suffix.lower() in ['.dbf','.shp','.shx','.prj']:
            target=dest/pathlib.Path(n).name
            if not target.exists():
                with z.open(n) as a,target.open('wb') as b:
                    while chunk:=a.read(1048576):b.write(chunk)
    reader=shapefile.Reader(str(next(dest.glob('*.shp'))),encoding='cp1252',encodingErrors='replace')
    for rec in reader.iterRecords(fields=['PROCESSO']):
        key=rec[0].replace('.','')
        if key not in keys:continue
        bbox=list(reader.shape(rec.oid).bbox)
        if key in boxes:
            a=boxes[key];bbox=[min(a[0],bbox[0]),min(a[1],bbox[1]),max(a[2],bbox[2]),max(a[3],bbox[3])]
        boxes[key]=bbox
    print(filename,len(boxes),flush=True)
(p/'coordinates.json').write_text(json.dumps({k:[round((v[0]+v[2])/2,5),round((v[1]+v[3])/2,5)] for k,v in boxes.items()}))
