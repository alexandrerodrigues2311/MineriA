import pathlib,sys,zipfile,csv,json,collections
p=pathlib.Path(__file__).parent;sys.path.insert(0,str(p/'geo_deps'));import shapefile
out=p.parent/'painel-anm'/'dist'/'details';out.mkdir(exist_ok=True)
def read(path):return csv.DictReader(path.open(encoding='utf-8-sig'),delimiter=';')
keys={r['ProcessoMinerario'] for r in read(p/'ResultadoRodadaDisponibilidade.csv')};keys.update(r['ProcessoMinerario'] for r in read(p/'ResultadoAvaliacaoSocial.csv'));keys.update(r['ProcessoMinerario'] for r in read(p/'EstoqueAreas.csv'));details={k:{'events':[],'polygons':[]} for k in keys}
for r in read(p/'scm_sople'/'ProcessoEvento.csv'):
    k=r['DSProcesso'].replace('.','')
    if k in details:details[k]['events'].append([r['DTEvento'],r['IDEvento']])
for filename in ['BRASIL','PROCESSOS_INATIVOS']:
    dest=p/'geometry'/filename;reader=shapefile.Reader(str(next(dest.glob('*.shp'))),encoding='cp1252',encodingErrors='replace')
    for rec in reader.iterRecords(fields=['PROCESSO','DSProcesso']):
        candidates=[str(x).replace('.','') for x in rec];k=next((x for x in candidates if x in keys),None)
        if not k:continue
        shape=reader.shape(rec.oid);pts=shape.points;part=list(shape.parts)+[len(pts)]
        rings=[[[round(x,7),round(y,7)] for x,y in pts[part[i]:part[i+1]]] for i in range(len(part)-1)]
        if rings:details[k]['polygons'].append(rings)
    print(filename,'done',flush=True)
buckets=collections.defaultdict(dict)
for k,d in details.items():d['events'].sort();buckets[k[:4]][k]=d
coordinates={}
for k,d in details.items():
    points=[point for poly in d['polygons'] for ring in poly for point in ring]
    if points:coordinates[k]=[round((min(t[0] for t in points)+max(t[0] for t in points))/2,6),round((min(t[1] for t in points)+max(t[1] for t in points))/2,6)]
(p/'coordinates.json').write_text(json.dumps(coordinates))
for key,value in buckets.items():(out/(key+'.json')).write_text(json.dumps(value,separators=(',',':')))
print(json.dumps({'processes':len(details),'with_polygon':sum(bool(d['polygons']) for d in details.values()),'events':sum(len(d['events']) for d in details.values()),'buckets':len(buckets),'bytes':sum(f.stat().st_size for f in out.glob('*.json'))}))
(p/'details_report.json').write_text(json.dumps({'processes':len(details),'with_polygon':sum(bool(d['polygons']) for d in details.values()),'with_events':sum(bool(d['events']) for d in details.values()),'events':sum(len(d['events']) for d in details.values()),'buckets':len(buckets)}))
