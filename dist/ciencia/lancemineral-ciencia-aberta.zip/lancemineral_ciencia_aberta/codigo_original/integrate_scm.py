import csv,io,zipfile,json,collections,pathlib,hashlib
p=pathlib.Path(__file__).parent; out=p/'scm_sople';out.mkdir(exist_ok=True)
rows=list(csv.DictReader((p/'ResultadoRodadaDisponibilidade.csv').open(encoding='utf-8-sig'),delimiter=';'))
keys={r['ProcessoMinerario'].replace('.','') for r in rows}
keys.update(r['ProcessoMinerario'].replace('.','') for r in csv.DictReader((p/'ResultadoAvaliacaoSocial.csv').open(encoding='utf-8-sig'),delimiter=';'))
auction_keys=set(keys)
keys.update(r['ProcessoMinerario'].replace('.','') for r in csv.DictReader((p/'EstoqueAreas.csv').open(encoding='utf-8-sig'),delimiter=';'))
z=zipfile.ZipFile(p/'scm.zip'); report={}
for table in ['Processo','ProcessoEvento','ProcessoPessoa','ProcessoTitulo','ProcessoSubstancia','ProcessoMunicipio','ProcessoAssociacao','ProcessoDocumentacao','ProcessoPropriedadeSolo']:
    reader=csv.DictReader(io.TextIOWrapper(z.open('microdados-scm/'+table+'.txt'),encoding='cp1252'),delimiter=';')
    total=matched=bad=0; found=set(); dates=collections.Counter()
    with (out/(table+'.csv')).open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=reader.fieldnames,delimiter=';');writer.writeheader()
        for r in reader:
            total+=1
            if None in r or any(v is None for v in r.values()):bad+=1;continue
            key=r['DSProcesso'].replace('.','')
            if key in keys:
                writer.writerow(r);matched+=1;found.add(key)
                for k in ['DTEvento','DTInicioVigencia','DTPublicacao']:
                    if k in r:dates['dated' if r[k] else 'missing']+=1
    report[table]={'source_rows':total,'matched_rows':matched,'matched_processes':len(found),'unmatched_sople_processes':len(keys-found),'malformed_rows':bad,'dates':dict(dates)}
    print(table,report[table],flush=True)
for table in ['Evento','Substancia','TipoRelacao','TipoAssociacao','DocumentoLegal','FaseProcesso']:
    (out/(table+'.csv')).write_bytes(z.read('microdados-scm/'+table+'.txt').decode('cp1252').encode('utf-8'))
report['sople_unique_processes']=len(auction_keys)
report['stock_and_rounds_unique_processes']=len(keys)
(p/'integration_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
