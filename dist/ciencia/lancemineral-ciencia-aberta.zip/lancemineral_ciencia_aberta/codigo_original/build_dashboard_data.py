import pathlib,csv,json,collections,datetime,hashlib,shutil
p=pathlib.Path(__file__).parent;out=p.parent/'painel-anm'/'dist';out.mkdir(parents=True,exist_ok=True)
def read(path):return list(csv.DictReader(path.open(encoding='utf-8-sig'),delimiter=';'))
def number(x):return float(x.replace('.','').replace(',','.'))
def norm(x):return x.replace('.','')
g=collections.defaultdict(list)
for r in read(p/'ResultadoRodadaDisponibilidade.csv'):
    if r['Rodada'] in ['1','2','3','4','5','8']:g[(r['Rodada'],r['NumeroArea'],r['ProcessoMinerario'])].append(r)
stock={r['ProcessoMinerario']:r for r in read(p/'EstoqueAreas.csv')};coord=json.loads((p/'coordinates.json').read_text());context=json.loads((p/'economic_context.json').read_text());old={r['rodada']+'|'+r['area']:r for r in read(p.parent/'outputs'/'base_analitica_inicial.csv')}
events=collections.defaultdict(list)
for r in read(p/'scm_sople'/'ProcessoEvento.csv'):events[norm(r['DSProcesso'])].append([r['DTEvento'],r['IDEvento']])
for k in events:events[k]=sorted(events[k],reverse=True)[:5]
evrows=read(p/'scm_sople'/'Evento.csv');evnames={r['IDEvento']:r.get('NMEvento',r.get('DSEvento',str(r['IDEvento']))) for r in evrows}
stale=(p/'model_stale.flag').exists()
pred={r['area']:r for r in json.loads((p/'predictions_v2.json').read_text())} if (p/'predictions_v2.json').exists() and not stale else {}
rows=[];excluded=collections.Counter()
for (rd,area,key),group in g.items():
    chosen=[r for r in group if 'Fechada' in r['Modalidade']] or group
    if len(chosen)!=1:raise ValueError('Ambiguous phase')
    r=chosen[0]
    if r['Situacao'] not in ['Arrematada','Livre','Conquistada']:excluded[r['Situacao']]+=1;continue
    o=old.get(rd+'|'+area,{});cx=context.get(key+'|'+rd,{});s=stock.get(key,{})
    row={'r':int(rd),'a':area,'p':key,'s':r['Situacao'],'v':number(r['ValorLanceVencedorReais']),'u':r['UnidadeFederacao'],'m':r['Municipio'],'ha':number(r['AreaPoligonal']),'reg':r['RegimeDisponibilidade'],'sub':s.get('Substancia','Sem registro'),'xy':coord.get(key),'ev':events.get(key,[]),'hist':int(o.get('eventos_anteriores',0)),'tit':int(o.get('titulos_publicados',0)),'cf':None if cx.get('cfem_sem_registro',1) else round(__import__('math').expm1(cx['cfem_log_3anos']),2),'di':None if cx.get('dipem_sem_registro',1) else round(__import__('math').expm1(cx['dipem_log_3anos']),2)}
    if rd=='8' and area in pred:row['pred']=pred[area]
    rows.append(row)
assert len({(r['r'],r['a'],r['p']) for r in rows})==len(rows)
report=json.loads((p.parent/'outputs'/'experimento_ml_v2.json').read_text(encoding='utf-8')) if (p.parent/'outputs'/'experimento_ml_v2.json').exists() and not stale else None
snapshot=json.loads((p/'source_snapshot.json').read_text()) if (p/'source_snapshot.json').exists() else {'extracted_at':'2026-09-24T00:00:00-03:00'}
data={'extracted_at':snapshot['extracted_at'],'model_frozen_at':'2026-09-24','rows':rows,'events':evnames,'model':report,'baseline':json.loads((p.parent/'outputs'/'experimento_ml.json').read_text(encoding='utf-8')),'excluded':dict(excluded),'integration':json.loads((p/'integration_report.json').read_text()),'geometry':json.loads((p/'geometry_report.json').read_text()),'coordinates':sum(bool(r['xy']) for r in rows),'sources':[{'name':'SOPLE','url':'https://dadosabertos.anm.gov.br/SOPLE/'},{'name':'Cadastro Mineiro','url':'https://dadosabertos.anm.gov.br/SCM/'},{'name':'SIGMINE','url':'https://dadosabertos.anm.gov.br/SIGMINE/PROCESSOS_MINERARIOS/'},{'name':'CFEM','url':'https://dadosabertos.anm.gov.br/CFEM/'},{'name':'DIPEM','url':'https://dadosabertos.anm.gov.br/DIPEM/'}]}
temp=out/'data.next.json';temp.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8');temp.replace(out/'data.json')
print(json.dumps({'rows':len(rows),'bytes':(out/'data.json').stat().st_size,'sum_bids':sum(r['v'] for r in rows),'located':data['coordinates'],'model_ready':bool(report)}))
