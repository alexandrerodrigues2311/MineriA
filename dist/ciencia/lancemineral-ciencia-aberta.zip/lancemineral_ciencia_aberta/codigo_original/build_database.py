"""Local relational analytical package. Raw identity fields are omitted."""
import pathlib,csv,json,sqlite3,hashlib,collections,datetime
p=pathlib.Path(__file__).parent;out=p.parent/'outputs';target=out/'base_integrada_anm.sqlite';tmp=out/'base_integrada_anm.next.sqlite'
if tmp.exists():tmp.unlink()
c=sqlite3.connect(tmp);counts={}
def insert_table(name,path,encoding='utf-8-sig',delimiter=';',exclude=()):
    with path.open(encoding=encoding,newline='') as f:
        reader=csv.DictReader(f,delimiter=delimiter);fields=[k for k in reader.fieldnames if k not in exclude];c.execute('CREATE TABLE "'+name+'" ('+','.join('"'+k+'" TEXT' for k in fields)+')');batch=[];count=0
        for r in reader:
            batch.append([r.get(k) for k in fields]);count+=1
            if len(batch)>=5000:c.executemany('INSERT INTO "'+name+'" VALUES ('+','.join('?' for _ in fields)+')',batch);batch=[]
        if batch:c.executemany('INSERT INTO "'+name+'" VALUES ('+','.join('?' for _ in fields)+')',batch)
        counts[name]=count
        for key in ['DSProcesso','ProcessoMinerario','processo']:
            if key in fields:c.execute('CREATE INDEX "idx_'+name+'" ON "'+name+'" ("'+key+'")');break
insert_table('sople_resultados_todas_fases',p/'ResultadoRodadaDisponibilidade.csv',exclude=['NomeVencedor','CpfCnpjVencedor'])
insert_table('sople_estoque',p/'EstoqueAreas.csv')
insert_table('sople_avaliacao_social',p/'ResultadoAvaliacaoSocial.csv',exclude=['NomeVencedor','CpfCnpjVencedor','NomeInteressado','CpfCnpjInteressado'])
for file in (p/'scm_sople').glob('*.csv'):insert_table('scm_'+file.stem,file,exclude=['OBEvento','DSPublicacaoDOU','OBAssociacao'])
insert_table('analitica_comercial',out/'base_analitica_inicial.csv')
insert_table('comparacao_rodadas',out/'comparacao_rodadas.csv')
c.execute('CREATE TABLE contexto_area_rodada(processo TEXT,rodada INTEGER,variaveis_json TEXT,PRIMARY KEY(processo,rodada))')
cx=json.loads((p/'economic_context.json').read_text());c.executemany('INSERT INTO contexto_area_rodada VALUES (?,?,?)',[(k.split('|')[0],int(k.split('|')[1]),json.dumps(v)) for k,v in cx.items()]);counts['contexto_area_rodada']=len(cx)
c.execute('CREATE TABLE localizacao_atual(processo TEXT PRIMARY KEY,longitude REAL,latitude REAL)');geo=json.loads((p/'coordinates.json').read_text());c.executemany('INSERT INTO localizacao_atual VALUES (?,?,?)',[(k,*v) for k,v in geo.items()]);counts['localizacao_atual']=len(geo)
c.execute('CREATE TABLE fontes(arquivo TEXT PRIMARY KEY,sha256 TEXT,bytes INTEGER,extraido_em TEXT)')
for file in [*p.glob('*.csv'),p/'scm.zip',p/'BRASIL.zip',p/'PROCESSOS_INATIVOS.zip',p/'ipca.json']:
    h=hashlib.sha256()
    with file.open('rb') as f:
        while b:=f.read(1048576):h.update(b)
    c.execute('INSERT INTO fontes VALUES (?,?,?,?)',(file.name,h.hexdigest(),file.stat().st_size,'2026-09-24'))
c.commit();assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';c.close();tmp.replace(target)
(out/'inventario_base_integrada.json').write_text(json.dumps({'tables':counts,'scope':'Full SOPLE stock and all result stages; SCM relationships restricted to SOPLE process universe; CFEM/DIPEM integrated as lagged municipal context; current geometry representative points. Not all ANM datasets.','privacy':'Winner names/documents and event free text omitted. No private bidding information.'},ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(counts))
