import pathlib,csv,json,collections,datetime
p=pathlib.Path(__file__).parent;out=p.parent/'painel-anm'/'dist'
def read(name):return list(csv.DictReader((p/name).open(encoding='utf-8-sig'),delimiter=';'))
def number(s):return float((s or '0').replace('.','').replace(',','.'))
groups=collections.defaultdict(list);records=read('ResultadoRodadaDisponibilidade.csv')
for r in records:groups[(r['Rodada'],r['NumeroArea'],r['ProcessoMinerario'])].append(r)
allrows=[];original=json.loads((out/'data.json').read_text(encoding='utf-8'));existing={(r['r'],r['a'],r['p']):r for r in original['rows']};stock={r['ProcessoMinerario']:r for r in read('EstoqueAreas.csv')};coords=json.loads((p/'coordinates.json').read_text());rounds=collections.defaultdict(list)
for (rd,a,k),rs in groups.items():
    chosen=[r for r in rs if 'Fechada' in r['Modalidade']] or rs
    assert len(chosen)==1
    r=chosen[0];row=existing.get((int(rd),a,k),{'r':int(rd),'a':a,'p':k,'s':r['Situacao'],'v':number(r['ValorLanceVencedorReais']),'u':r['UnidadeFederacao'],'m':r['Municipio'],'ha':number(r['AreaPoligonal']),'reg':r['RegimeDisponibilidade'],'sub':stock.get(k,{}).get('Substancia','Sem registro'),'xy':coords.get(k),'ev':[],'hist':None,'tit':None,'cf':None,'di':None});allrows.append(row);rounds[int(rd)].append(row)
for r in read('ResultadoAvaliacaoSocial.csv'):
    k=r['ProcessoMinerario'];row={'r':int(r['Rodada']),'a':r['NumeroArea'],'p':k,'s':r['Situacao'],'v':0,'u':r['UnidadeFederacao'],'m':r['Municipio'],'ha':number(r['AreaPoligonal']),'reg':r['RegimeDisponibilidade'],'sub':stock.get(k,{}).get('Substancia','Sem registro'),'xy':coords.get(k),'ev':[],'hist':None,'tit':None,'cf':None,'di':None};allrows.append(row);rounds[int(r['Rodada'])].append(row)
report=[]
for rd,rows in sorted(rounds.items()):
    valid=[r for r in rows if r['s'] in ['Livre','Conquistada','Arrematada']] if rd!=6 else []
    report.append({'round':rd,'areas_in_dataset':len(rows),'commercial_valid':len(valid),'won':sum(r['s']=='Arrematada' for r in rows),'total_bids':round(sum(r['v'] for r in rows),2),'statuses':dict(collections.Counter(r['s'] for r in rows)),'unique_processes':len({r['p'] for r in rows})})
st=collections.Counter(r['SituacaoEstoque'] for r in stock.values());result={'rows':allrows,'rounds':report,'total_included':len(allrows),'unique_processes':len({r['p'] for r in allrows}),'stock_count':len(stock),'stock_statuses':dict(st),'snapshot':'2026-09-24','description':'Areas counted per round, including cancelled round 7 and social round 6; not unique physical land parcels. Snapshot does not substitute original edital annex.'}
(out/'overview.json').write_text(json.dumps(result,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
(p.parent/'outputs'/'visao_geral_rodadas.json').write_text(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'rounds':report,'included':len(allrows),'unique':result['unique_processes']},ensure_ascii=True))
