import pathlib,sys,json,csv,collections,math
p=pathlib.Path(__file__).parent;sys.path.insert(0,str(p/'ml_deps'))
import numpy as np,joblib
from sklearn.feature_extraction import DictVectorizer
from sklearn.ensemble import HistGradientBoostingClassifier,HistGradientBoostingRegressor
from sklearn.metrics import roc_auc_score,brier_score_loss,mean_absolute_error,mean_squared_log_error
z=joblib.load(p/'features_v2.joblib');rows=z['final'];sets=z['sets'];y=np.array([r['target'] for r in rows]);bid=np.array([r['bid'] for r in rows]);groups=collections.defaultdict(list)
for i,r in enumerate(rows):groups[int(r['Rodada'])].append(i)
ipca=json.loads((p/'ipca.json').read_text());price={};acc=1
for r in ipca:
    d,m,yr=r['data'].split('/');acc*=1+float(r['valor'])/100;price[int(yr),int(m)]=acc
base=price[2019,11]; roundstats={};aggregate={}
for rd,ii in groups.items():
    uf=collections.Counter(rows[i]['UnidadeFederacao'] for i in ii);reg=collections.Counter(rows[i]['RegimeDisponibilidade'] for i in ii);areas=[math.expm1(sets['basico'][i]['log_hectares']) for i in ii]
    positive=bid[ii][y[ii]==1];year=int(rows[ii[0]]['cutoff'][:4]);ratio=price[year-1,11]/base
    roundstats[rd]={'round':rd,'n':len(ii),'win_rate':float(y[ii].mean()),'sum':float(bid[ii].sum()),'median_bid':float(np.median(positive)),'median_area':float(np.median(areas)),'uf_shares':{k:v/len(ii) for k,v in uf.items()},'regime_shares':{k:v/len(ii) for k,v in reg.items()},'ipca_relative_nov2019':ratio,'top_ufs':uf.most_common(3),'history_mean':float(np.mean([sets['historico'][i]['eventos_anteriores'] for i in ii]))}
    aggregate[rd]={'portfolio_log_n':math.log1p(len(ii)),'portfolio_log_area_mediana':math.log1p(np.median(areas)),'portfolio_uf_hhi':sum((v/len(ii))**2 for v in uf.values()),'portfolio_historia_media':roundstats[rd]['history_mean']}
    for key,val in reg.items():aggregate[rd]['portfolio_regime_'+key]=val/len(ii)
features=[];inflation=[]
for i,r in enumerate(rows):
    rd=int(r['Rodada']);year=int(r['cutoff'][:4]);f=dict(sets['territorial'][i]);f.update(aggregate[rd]);f['oferta_mesmo_estado']=roundstats[rd]['uf_shares'][r['UnidadeFederacao']];f['idade_processo']=year-int(r['ProcessoMinerario'].split('/')[1]);f['ipca_indice']=roundstats[rd]['ipca_relative_nov2019'];features.append(f);inflation.append(f['ipca_indice'])
inflation=np.array(inflation)
def idx(rr):return np.array([i for i,r in enumerate(rows) if int(r['Rodada']) in rr])
def remove(a,b):
    keys={rows[i]['ProcessoMinerario'] for i in b};return np.array([i for i in a if rows[i]['ProcessoMinerario'] not in keys])
report={'status':'exploratory_round_context','features_added':list(aggregate[1])+['oferta_mesmo_estado','idade_processo','ipca_indice'],'target':'log1p of positive bids deflated to November 2019; reconverted with known pre-cutoff index','limitations':['Portfolio composition reconstructed from current final commercial rows, not original annex vintages. Withdrawals can change it: exploratory sensitivity only.','Six commercial rounds do not identify independent causal effects of changing rules.','Bidding floors and deadlines unverified for all final edital versions; kept null, not invented.','IPCA monthly series 433, November preceding conservative annual cutoff, excludes unreleased December.','2024 test already inspected; no prospective claim.'],'evaluations':{}}
for name,trainrounds,testround in [('validation5',[1,2,3],5),('retrospective8',[1,2,3,4,5],8)]:
    te=idx([testround]);tr=remove(idx(trainrounds),te);v=DictVectorizer(sparse=False);a=v.fit_transform([features[i] for i in tr]);b=v.transform([features[i] for i in te]);c=HistGradientBoostingClassifier(max_iter=150,max_leaf_nodes=15,l2_regularization=10,random_state=42);g=HistGradientBoostingRegressor(max_iter=150,max_leaf_nodes=15,l2_regularization=10,random_state=42)
    c.fit(a,y[tr]);prob=c.predict_proba(b)[:,1];g.fit(a[y[tr]==1],np.log1p(bid[tr][y[tr]==1]/inflation[tr][y[tr]==1]));pred=np.maximum(0,np.expm1(g.predict(b))*inflation[te]);pos=y[te]==1
    report['evaluations'][name]={'auc':float(roc_auc_score(y[te],prob)),'brier':float(brier_score_loss(y[te],prob)),'rmsle':float(np.sqrt(mean_squared_log_error(bid[te][pos],pred[pos]))),'mae':float(mean_absolute_error(bid[te][pos],pred[pos])),'train_n':len(tr),'test_n':len(te)};print(name,report['evaluations'][name],flush=True)
# Drift in the same measured features, without using outcomes as predictors.
historical=idx([1,2,3,4,5]);test=idx([8]);allufs={r['UnidadeFederacao'] for r in rows}
def share(ii,uf):return sum(rows[i]['UnidadeFederacao']==uf for i in ii)/len(ii)
report['drift']={'uf_total_variation':.5*sum(abs(share(historical,u)-share(test,u)) for u in allufs),'historical_positive_rate':float(y[historical].mean()),'round8_positive_rate':float(y[test].mean()),'historical_median_positive':float(np.median(bid[historical][y[historical]==1])),'round8_median_positive':float(np.median(bid[test][y[test]==1]))}
(p.parent/'outputs'/'mudancas_rodadas.json').write_text(json.dumps({'rounds':list(roundstats.values()),'experiment':report},ensure_ascii=False,indent=2),encoding='utf-8')
with (p.parent/'outputs'/'comparacao_rodadas.csv').open('w',encoding='utf-8-sig',newline='') as f:
    fields=['round','n','win_rate','sum','median_bid','median_area','history_mean','ipca_relative_nov2019'];w=csv.DictWriter(f,fieldnames=fields,delimiter=';');w.writeheader();w.writerows({k:r[k] for k in fields} for r in roundstats.values())
print(json.dumps(report,ensure_ascii=True),flush=True)
