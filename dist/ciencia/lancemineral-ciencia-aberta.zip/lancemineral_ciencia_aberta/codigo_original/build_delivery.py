"""Derive lightweight delivery files and anonymous participant summaries from source snapshots."""
from pathlib import Path
import json,csv,collections,hashlib,re,unicodedata
p=Path(__file__).resolve().parent; d=p.parent/'painel-anm'/'dist'
def read(n): return list(csv.DictReader((p/n).open(encoding='utf-8-sig'),delimiter=';'))
def save(n,v):
    b=json.dumps(v,ensure_ascii=False,separators=(',',':')).encode();(d/n).write_bytes(b);return hashlib.sha256(b).hexdigest()[:16]
base=json.loads((d/'data.json').read_text(encoding='utf-8'));ov=json.loads((d/'overview.json').read_text(encoding='utf-8'))
rows=ov['rows'];compact=[{k:v for k,v in r.items() if k!='ev'} for r in rows]
revision=save('areas.json',compact)
meta={**base,'rows':[],'areas_revision':revision};save('metadata.json',meta)
states=collections.defaultdict(float)
for r in rows: states[r['u']]+=r['v'] or 0
save('overview-summary.json',{**ov,'rows':[],'areas_revision':revision,'state_totals':dict(states)})
def key(name,doc): return (' '.join(name.upper().split()),re.sub(r'[^0-9*]','',doc))
def typ(doc):
    n=len(re.sub(r'[^0-9*]','',doc))
    return 'Pessoa jurídica' if n==14 else 'Pessoa física' if n==11 else 'Não identificado'
participants=read('InteressadoParticipante.csv'); results=read('ResultadoRodadaDisponibilidade.csv')
ufnames='Acre|Alagoas|Amapá|Amazonas|Bahia|Ceará|Distrito Federal|Espírito Santo|Goiás|Maranhão|Mato Grosso|Mato Grosso do Sul|Minas Gerais|Pará|Paraíba|Paraná|Pernambuco|Piauí|Rio de Janeiro|Rio Grande do Norte|Rio Grande do Sul|Rondônia|Roraima|Santa Catarina|São Paulo|Sergipe|Tocantins'.split('|')
ufs='AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split()
def fold(s):return ''.join(c for c in unicodedata.normalize('NFKD',s.upper().strip()) if not unicodedata.combining(c))
ufmap={fold(n):uf for n,uf in zip(ufnames,ufs)}
for r in participants:
    r['UnidadeFederacao']=ufmap.get(fold(r['UnidadeFederacao']),r['UnidadeFederacao'].strip().upper()) or 'Sem registro'
    r['Municipio']=' '.join(r['Municipio'].upper().split()) or 'SEM REGISTRO'
groups=collections.defaultdict(list)
for r in results:groups[(r['Rodada'],r['NumeroArea'],r['ProcessoMinerario'])].append(r)
winners=[]
for rs in groups.values():
    r=([r for r in rs if 'Fechada' in r['Modalidade']] or rs)[0]
    if r['Situacao']=='Arrematada':winners.append(r)
def amount(r):return float(r['ValorLanceVencedorReais'].replace('.','').replace(',','.'))
def summarize(rd):
    ps=[r for r in participants if not rd or int(r['Rodada'])==rd];ws=[r for r in winners if not rd or int(r['Rodada'])==rd]
    distinct={(r['Rodada'],*key(r['NomeInteressado'],r['CpfCnpjInteressado']),r['Municipio'],r['UnidadeFederacao'],r['ModalidadeParticipacao']) for r in ps}
    identities={key(r['NomeInteressado'],r['CpfCnpjInteressado']) for r in ps}
    wk=collections.Counter(key(r['NomeVencedor'],r['CpfCnpjVencedor']) for r in ws if r['NomeVencedor'].strip())
    money=collections.defaultdict(float)
    for r in ws:money[key(r['NomeVencedor'],r['CpfCnpjVencedor'])]+=amount(r)
    total=sum(amount(r) for r in ws)
    group=lambda field:dict(collections.Counter(r[field] or 'Sem registro' for r in ps))
    types=[]
    for t in ['Pessoa física','Pessoa jurídica','Não identificado']:
        a=[r for r in ps if typ(r['CpfCnpjInteressado'])==t];b=[r for r in ws if typ(r['CpfCnpjVencedor'])==t]
        types.append({'type':t,'participants':len({key(r['NomeInteressado'],r['CpfCnpjInteressado']) for r in a}),'won':len(b),'bids':round(sum(amount(r) for r in b),2)})
    locations=collections.Counter((r['UnidadeFederacao'],r['Municipio']) for r in ps)
    return {'round':rd,'records':len(ps),'duplicates':len(ps)-len(distinct),'participants':len(identities),'winners':len(wk),'won':len(ws),'bids':round(total,2),'multiple':sum(n>1 for n in wk.values()),'top10_share':sum(sorted(money.values(),reverse=True)[:10])/total if total else None,'types':types,'modalities':group('ModalidadeParticipacao'),'locations':[[uf,city,n] for (uf,city),n in locations.most_common()], 'states':group('UnidadeFederacao')}
save('participants.json',{'snapshot':base['extracted_at'],'all':summarize(0),'rounds':[summarize(n) for n in range(1,9)],'source':'https://dadosabertos.anm.gov.br/SOPLE/'})
report={'before_initial_json_bytes':sum((d/n).stat().st_size for n in ['data.json','overview.json','characteristics.json']),'after_initial_json_bytes':sum((d/n).stat().st_size for n in ['metadata.json','overview-summary.json']),'areas_on_demand_bytes':(d/'areas.json').stat().st_size,'participant_records':len(participants),'won_areas':len(winners),'bids':round(sum(amount(r) for r in winners),2),'revision':revision}
assert len(rows)==ov['total_included'];assert len(winners)==sum(r['won'] for r in ov['rounds']);assert abs(report['bids']-sum(r['total_bids'] for r in ov['rounds']))<.01
(p.parent/'outputs'/'verificacao_entrega_mineria.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
