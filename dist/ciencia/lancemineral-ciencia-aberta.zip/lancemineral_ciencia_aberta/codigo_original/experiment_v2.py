"""Retrospective temporal benchmark. Round 5 selects; round 8 evaluates.
Round 8 was examined in v1 and is NOT an untouched prospective test.
"""
exec(compile((__import__('pathlib').Path(__file__).parent/'experiment_ml.py').read_text(encoding='utf-8').split('train=np.array')[0],__file__,'exec'))
from sklearn.ensemble import ExtraTreesClassifier,ExtraTreesRegressor,HistGradientBoostingClassifier,HistGradientBoostingRegressor
from sklearn.linear_model import LogisticRegression,Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
import joblib,hashlib
cf=collections.defaultdict(float); dip=collections.defaultdict(float)
for name in ['CFEM_Arrecadacao_2017_2021.csv','CFEM_Arrecadacao_2022_2026.csv']:
    for r in csv.DictReader((p/name).open(encoding='cp1252')):
        cf[(r['CodigoMunicipio'],int(r['Ano']))]+=num(r['ValorRecolhido'])
for r in csv.DictReader((p/'InvestimentoPesquisaMineralMunicipio.csv').open(encoding='cp1252'),delimiter=';'):
    if r['CodigoMunicipio'].isdigit():dip[(r['CodigoMunicipio'],int(r['Ano']))]+=sum(num(v) for k,v in r.items() if k.startswith('Valor'))
munis=collections.defaultdict(set)
for r in read(q/'ProcessoMunicipio.csv'):munis[norm(r['DSProcesso'])].add(r['IDMunicipio'])
assoc=collections.defaultdict(list)
for r in read(q/'ProcessoAssociacao.csv'):assoc[norm(r['DSProcesso'])].append(r)
extended=[];context={}
for r,base in zip(final,enhanced):
    f=dict(base);year=int(r['cutoff'][:4]);mm=munis[r['ProcessoMinerario']]
    f['associacoes_anteriores']=sum(bool(e['DTAssociacao']) and e['DTAssociacao']<r['cutoff'] for e in assoc[r['ProcessoMinerario']])
    f['municipio_ausente']=int(not mm)
    for name,source in [('cfem',cf),('dipem',dip)]:
        vals=[source[(m,y)] for m in mm for y in range(year-4,year-1) if (m,y) in source]
        f[name+'_sem_registro']=int(not vals)
        f[name+'_log_3anos']=math.log1p(max(0,sum(vals)))
    extended.append(f)
    context[r['ProcessoMinerario']+'|'+r['Rodada']]={k:v for k,v in f.items() if k.startswith(('cfem','dipem','municipio_','associacoes_'))}
(p/'economic_context.json').write_text(json.dumps(context))
y=np.array([r['target'] for r in final]);bid=np.array([r['bid'] for r in final])
idx=lambda rounds:np.array([i for i,r in enumerate(final) if int(r['Rodada']) in rounds])
valid=idx([5]);test=idx([8]);tv=idx([1,2,3]);tr=idx([1,2,3,4,5])
def remove_overlap(a,b):
    kk={final[i]['ProcessoMinerario'] for i in b};return np.array([i for i in a if final[i]['ProcessoMinerario'] not in kk])
tv=remove_overlap(tv,valid);tr=remove_overlap(tr,test)
def models(kind):
    if kind=='rf':return RandomForestClassifier(n_estimators=180,max_depth=12,min_samples_leaf=20,max_features=.7,n_jobs=4,random_state=42),RandomForestRegressor(n_estimators=180,max_depth=12,min_samples_leaf=12,max_features=.7,n_jobs=4,random_state=42)
    if kind=='extra':return ExtraTreesClassifier(n_estimators=180,max_depth=16,min_samples_leaf=15,max_features=.8,n_jobs=4,random_state=42),ExtraTreesRegressor(n_estimators=180,max_depth=16,min_samples_leaf=12,max_features=.8,n_jobs=4,random_state=42)
    if kind=='hgb':return HistGradientBoostingClassifier(max_iter=150,max_leaf_nodes=15,l2_regularization=10,random_state=42),HistGradientBoostingRegressor(max_iter=150,max_leaf_nodes=15,l2_regularization=10,random_state=42)
    return make_pipeline(StandardScaler(),LogisticRegression(C=.1,max_iter=1500)),make_pipeline(StandardScaler(),Ridge(alpha=100))
sets={'basico':basic,'historico':enhanced,'territorial':extended};candidates=[('rf','historico'),('extra','historico'),('hgb','basico'),('hgb','historico'),('linear','historico'),('hgb','territorial')]
report={'status':'experimental_retrospective','selection_round':5,'selection_train_rounds':[1,2,3],'final_train_rounds':[1,2,3,4,5],'evaluation_round':8,'selection':{},'test':{},'protocol':'Selection by Brier for occurrence and RMSLE for positive values. Round 4 excluded from validation training: homologation after round 5 opened. Round 8 examined previously, not pristine. Territorial features use current municipality links and annual totals lagged >=2 years; publication vintages unavailable.'}
for kind,fs in candidates:
    v=DictVectorizer(sparse=False);a=v.fit_transform([sets[fs][i] for i in tv]);b=v.transform([sets[fs][i] for i in valid]);clf,reg=models(kind)
    clf.fit(a,y[tv]);prob=clf.predict_proba(b)[:,1];reg.fit(a[y[tv]==1],np.log1p(bid[tv][y[tv]==1]));pred=np.maximum(0,np.expm1(reg.predict(b[y[valid]==1])))
    met={'auc':float(roc_auc_score(y[valid],prob)),'brier':float(brier_score_loss(y[valid],prob)),'rmsle':float(np.sqrt(mean_squared_log_error(bid[valid][y[valid]==1],pred))),'mae':float(mean_absolute_error(bid[valid][y[valid]==1],pred))}
    report['selection'][kind+'_'+fs]=met;print(kind,fs,met,flush=True)
chosen_c=min(report['selection'],key=lambda k:report['selection'][k]['brier']);chosen_r=min(report['selection'],key=lambda k:report['selection'][k]['rmsle']);report['chosen']={'classifier':chosen_c,'regressor':chosen_r}
predictions={}; saved={}
for task,key in [('classifier',chosen_c),('regressor',chosen_r)]:
    kind,fs=key.split('_',1);v=DictVectorizer(sparse=False);a=v.fit_transform([sets[fs][i] for i in tr]);b=v.transform([sets[fs][i] for i in test]);clf,reg=models(kind)
    if task=='classifier':clf.fit(a,y[tr]);predictions['p']=clf.predict_proba(b)[:,1];saved[task]=(v,clf)
    else:reg.fit(a[y[tr]==1],np.log1p(bid[tr][y[tr]==1]));predictions['value']=np.maximum(0,np.expm1(reg.predict(b)));saved[task]=(v,reg)
pos=y[test]==1;report['test']={'auc':float(roc_auc_score(y[test],predictions['p'])),'brier':float(brier_score_loss(y[test],predictions['p'])),'rmsle':float(np.sqrt(mean_squared_log_error(bid[test][pos],predictions['value'][pos]))),'mae':float(mean_absolute_error(bid[test][pos],predictions['value'][pos])),'n':len(test),'n_positive':int(pos.sum())}
report['validation_counts']={'train':len(tv),'validation':len(valid),'final_train':len(tr)}
joblib.dump(saved,p/'models_v2.joblib');joblib.dump({'sets':sets,'final':final,'train':tr,'test':test},p/'features_v2.joblib')
# Quantile bands are empirical predictions, not guaranteed calibrated intervals.
v=DictVectorizer(sparse=False);a=v.fit_transform([extended[i] for i in tr]);b=v.transform([extended[i] for i in test]);bands=[]
for quantile in [.1,.9]:
    m=HistGradientBoostingRegressor(loss='quantile',quantile=quantile,max_iter=150,max_leaf_nodes=15,l2_regularization=10,random_state=42)
    m.fit(a[y[tr]==1],np.log1p(bid[tr][y[tr]==1]));bands.append(np.maximum(0,np.expm1(m.predict(b))))
lo=np.minimum(*bands);hi=np.maximum(*bands)
report['interval']={'nominal_coverage':.8,'observed_coverage':float(np.mean((bid[test][pos]>=lo[pos])&(bid[test][pos]<=hi[pos]))),'median_width_reais':float(np.median(hi[pos]-lo[pos])),'features':'territorial','uncalibrated':True}
rows=[]
for j,i in enumerate(test):rows.append({'processo':final[i]['ProcessoMinerario'],'area':final[i]['NumeroArea'],'p':round(float(predictions['p'][j]),5),'value':round(float(predictions['value'][j]),2),'low':round(float(lo[j]),2),'high':round(float(hi[j]),2)})
(output/'experimento_ml_v2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');(p/'predictions_v2.json').write_text(json.dumps(rows))
print(json.dumps(report,ensure_ascii=True,indent=2),flush=True)
