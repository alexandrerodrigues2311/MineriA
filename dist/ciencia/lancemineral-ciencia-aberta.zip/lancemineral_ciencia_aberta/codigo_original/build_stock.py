import pathlib,csv,json,collections
p=pathlib.Path(__file__).parent;dist=p.parent/'painel-anm'/'dist';out=dist/'stock';out.mkdir(exist_ok=True)
fields=['ProcessoMinerario','UnidadeFederacao','Municipio','AreaPoligonal','Substancia','UsoSubstancia','RegimeDisponibilidade','IndicaNominacao','FaseProcessoMinerario','SituacaoProcesso','SituacaoEstoque','IndicaDisponibilizacaoEdital','UltimaSituacaoEdital']
raw=list(csv.DictReader((p/'EstoqueAreas.csv').open(encoding='utf-8-sig'),delimiter=';'));auctions=json.loads((dist/'overview.json').read_text(encoding='utf-8'));keys={r['p'] for r in auctions['rows']};buckets=collections.defaultdict(list);characteristics={};summaries=[]
for r in raw:
    values=[r[k] for k in fields];buckets[r['UnidadeFederacao']].append(values)
    if r['ProcessoMinerario'] in keys:characteristics[r['ProcessoMinerario']]=values
for i,(uf,rows) in enumerate(sorted(buckets.items())):
    name=str(i)+'.json';(out/name).write_text(json.dumps(rows,ensure_ascii=False,separators=(',',':')),encoding='utf-8');summaries.append({'uf':uf,'file':name,'count':len(rows)})
manifest={'fields':fields,'total':len(raw),'states':summaries,'status':dict(collections.Counter(r['SituacaoEstoque'] for r in raw)),'extracted_at':json.loads((p/'source_state.json').read_text()).get('EstoqueAreas.csv',{}).get('extracted_at','2026-09-24'),'characteristics_in_auction':len(characteristics)}
(out/'index.json').write_text(json.dumps(manifest,ensure_ascii=False),encoding='utf-8');(dist/'characteristics.json').write_text(json.dumps(characteristics,ensure_ascii=False,separators=(',',':')),encoding='utf-8');print(json.dumps({'stock':len(raw),'auction_characteristics':len(characteristics),'bytes':sum(f.stat().st_size for f in out.glob('*.json')),'largest':max(f.stat().st_size for f in out.glob('*.json'))}))
