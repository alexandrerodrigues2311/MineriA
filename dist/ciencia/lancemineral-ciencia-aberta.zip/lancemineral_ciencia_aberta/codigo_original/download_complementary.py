import urllib.request, pathlib, zipfile, json, xml.etree.ElementTree as ET
p=pathlib.Path(__file__).parent
files={'scm.zip':'https://dadosabertos.anm.gov.br/SCM/microdados/microdados-scm.zip','scm.ods':'https://dadosabertos.anm.gov.br/SCM/microdados/metadados-microdados-scm.ods','sigmine.ods':'https://dadosabertos.anm.gov.br/SIGMINE/metadados-sigmine.ods','edital-belmiro.pdf':'https://belmiro.cfa.org.br/downloads/edital.pdf'}
for name,url in files.items():
    path=p/name
    if not path.exists():
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
        with urllib.request.urlopen(req,timeout=60) as src, path.open('wb') as dst:
            while b:=src.read(1024*1024): dst.write(b)
    print(name,path.stat().st_size,flush=True)
    if name.endswith('.zip'):
        z=zipfile.ZipFile(path)
        print([(f.filename,f.file_size) for f in z.infolist()],flush=True)
    if name.endswith('.ods'):
        root=ET.fromstring(zipfile.ZipFile(path).read('content.xml'))
        text='\n'.join(' '.join(r.itertext()) for r in root.iter() if r.tag.endswith('}table-row'))
        (p/(name+'.txt')).write_text(text,encoding='utf-8')
