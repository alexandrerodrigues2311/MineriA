"""Exploratory holdout: rounds 1-5 train, round 8 test. No tuning on test.
Uses conservative annual historical cutoffs, NOT final pre-auction snapshots.
Run with bundled Python. Dependencies are isolated in work/ml_deps.
"""
import sys,pathlib,csv,json,collections,datetime,math
p=pathlib.Path(__file__).parent;sys.path.insert(0,str(p/'ml_deps'))
import numpy as np
from sklearn.feature_extraction import DictVectorizer
from sklearn.ensemble import RandomForestClassifier,RandomForestRegressor
from sklearn.metrics import roc_auc_score,brier_score_loss,mean_absolute_error,mean_squared_log_error
import sklearn
q=p/'scm_sople';output=p.parent/'outputs';output.mkdir(exist_ok=True)
def read(path):return list(csv.DictReader(path.open(encoding='utf-8-sig'),delimiter=';'))
def norm(s):return s.replace('.','')
def num(s):return float(s.replace('.','').replace(',','.'))
raw=read(p/'ResultadoRodadaDisponibilidade.csv');groups=collections.defaultdict(list)
for r in raw:
    if r['Rodada'] in ['1','2','3','4','5','8']:groups[(r['Rodada'],r['NumeroArea'],r['ProcessoMinerario'])].append(r)
final=[];excluded=collections.Counter()
for k,rr in groups.items():
    stage=[r for r in rr if 'Fechada' in r['Modalidade']] or rr
    if len(stage)!=1: excluded['ambiguous']+=1;continue
    r=dict(stage[0])
    if r['Situacao'] not in ['Arrematada','Conquistada','Livre']:excluded[r['Situacao']]+=1;continue
    r['target']=int(r['Situacao']=='Arrematada');r['bid']=num(r['ValorLanceVencedorReais'])
    assert (r['bid']>0)==bool(r['target'])
    r['cutoff']={'1':'2020-01-01','2':'2020-01-01','3':'2021-01-01','4':'2021-01-01','5':'2021-01-01','8':'2024-01-01'}[r['Rodada']]
    final.append(r)
lookup={norm(r['DSProcesso']):r for r in read(q/'Processo.csv')}
tables={}
for name in ['ProcessoEvento','ProcessoTitulo','ProcessoSubstancia','ProcessoPessoa']:
    tables[name]=collections.defaultdict(list)
    for r in read(q/(name+'.csv')):tables[name][norm(r['DSProcesso'])].append(r)
basic=[];enhanced=[];audit=collections.Counter()
for r in final:
    key=r['ProcessoMinerario'];cut=r['cutoff'];dt=datetime.date.fromisoformat(cut);proc=lookup.get(key,{})
    area=num(r['AreaPoligonal']);base={'uf':r['UnidadeFederacao'],'regime':r['RegimeDisponibilidade'],'log_hectares':math.log1p(abs(area)),'ano_processo':int(key.split('/')[1])}
    feats=dict(base)
    hist=[e for e in tables['ProcessoEvento'][key] if e['DTEvento'] and e['DTEvento']<cut]
    audit['events_excluded_after_cutoff']+=sum(e['DTEvento']>=cut for e in tables['ProcessoEvento'][key])
    feats['eventos_anteriores']=len(hist);feats['historico_ausente']=int(not hist)
    for e in hist:feats['evento_'+e['IDEvento']]=feats.get('evento_'+e['IDEvento'],0)+1
    if hist:
        last=max(e['DTEvento'] for e in hist);feats['dias_ultimo_evento']=(dt-datetime.date.fromisoformat(last)).days
    titles=[e for e in tables['ProcessoTitulo'][key] if e['DTPublicacao'] and e['DTPublicacao']<cut]
    feats['titulos_publicados']=len(titles)
    for e in titles:feats['titulo_'+e['IDTipoDocumentoLegal']]=feats.get('titulo_'+e['IDTipoDocumentoLegal'],0)+1
    # Any substance recorded with a start before cutoff. Do not use current end status.
    subs={e['IDSubstancia'] for e in tables['ProcessoSubstancia'][key] if e['DTInicioVigencia'] and e['DTInicioVigencia']<cut}
    feats['substancias_historicas']=len(subs)
    for s in subs:feats['substancia_'+s]=1
    holders={e['IDPessoa'] for e in tables['ProcessoPessoa'][key] if e['DTInicioVigencia'] and e['DTInicioVigencia']<cut and e['IDTipoRelacao']=='1'}
    feats['requerentes_titulares_historicos']=len(holders)
    basic.append(base);enhanced.append(feats)
train=np.array([i for i,r in enumerate(final) if r['Rodada']!='8']);test=np.array([i for i,r in enumerate(final) if r['Rodada']=='8'])
testkeys={final[i]['ProcessoMinerario'] for i in test}
before=len(train);train=np.array([i for i in train if final[i]['ProcessoMinerario'] not in testkeys])
y=np.array([r['target'] for r in final]);bid=np.array([r['bid'] for r in final]);pos_train=train[y[train]==1];pos_test=test[y[test]==1]
report={'status':'exploratory_not_production','sklearn_version':sklearn.__version__,'train_rounds':[1,2,3,4,5],'test_round':8,'train_rows':len(train),'test_rows':len(test),'train_positive':len(pos_train),'test_positive':len(pos_test),'train_rows_removed_overlap':before-len(train),'exclusions':dict(excluded),'cutoffs':{'1,2':'2020-01-01','3,4,5':'2021-01-01','8':'2024-01-01'},'audit':dict(audit),'metrics':{},'limitations':['Only one temporal holdout; no claim of prospective validation.','2026 source snapshot with event-date filtering does not prove historical publication availability.','Conservative annual cutoffs omit legitimate events before each edital.','Nominal reais; no inflation or commodity price adjustment.','SOPLE attributes assumed as offered; original edital reconciliation pending.','No payment data or causal interpretation.','Forest log-price predictions are conditional central values, not expected total revenue.','Current geometry and current holder identity excluded.']}
def metrics(prob,pred):
    return {'auc':float(roc_auc_score(y[test],prob)),'brier':float(brier_score_loss(y[test],prob)),'mae_positive_reais':float(mean_absolute_error(bid[pos_test],pred)),'rmsle_positive':float(np.sqrt(mean_squared_log_error(bid[pos_test],pred))),'median_predicted_positive':float(np.median(pred))}
report['train_arrematacao_rate']=float(y[train].mean());report['test_arrematacao_rate']=float(y[test].mean())
report['metrics']['referencia_constante']=metrics(np.full(len(test),y[train].mean()),np.full(len(pos_test),np.median(bid[pos_train])))
preds={}
for name,features in [('floresta_basica',basic),('floresta_historico',enhanced)]:
    v=DictVectorizer();Xtrain=v.fit_transform([features[i] for i in train]);Xtest=v.transform([features[i] for i in test])
    clf=RandomForestClassifier(n_estimators=200,max_depth=12,min_samples_leaf=20,max_features=.7,random_state=42,n_jobs=4)
    clf.fit(Xtrain,y[train]);prob=clf.predict_proba(Xtest)[:,1]
    reg=RandomForestRegressor(n_estimators=200,max_depth=12,min_samples_leaf=12,max_features=.7,random_state=42,n_jobs=4)
    reg.fit(v.transform([features[i] for i in pos_train]),np.log1p(bid[pos_train]));pred=np.expm1(reg.predict(v.transform([features[i] for i in pos_test])))
    report['metrics'][name]=metrics(prob,pred)
    preds[name]={'probability':prob.tolist(),'positive_predictions':pred.tolist()}
    report[name+'_features']=len(v.feature_names_)
    print(name,report['metrics'][name],flush=True)
(output/'experimento_ml.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
# Non-personal reusable analysis dataset; no raw participant names or documents.
fields=['rodada','area','processo','situacao','lance_reais','corte_historico','uf','regime','hectares','eventos_anteriores','titulos_publicados','substancias_historicas','requerentes_titulares_historicos']
with (output/'base_analitica_inicial.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields,delimiter=';');w.writeheader()
    for r,e in zip(final,enhanced):
        w.writerow(dict(zip(fields,[r['Rodada'],r['NumeroArea'],r['ProcessoMinerario'],r['Situacao'],str(r['bid']),r['cutoff'],r['UnidadeFederacao'],r['RegimeDisponibilidade'],num(r['AreaPoligonal']),e['eventos_anteriores'],e['titulos_publicados'],e['substancias_historicas'],e['requerentes_titulares_historicos']])))
print(json.dumps(report,ensure_ascii=True,indent=2))
