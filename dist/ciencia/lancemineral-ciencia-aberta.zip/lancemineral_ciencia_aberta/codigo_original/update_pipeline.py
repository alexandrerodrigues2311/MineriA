"""Automatic source check/integration. Publishing is handled by the daily task.
No model retraining. Any relevant source revision invalidates displayed predictions.
"""
import pathlib,urllib.request,urllib.error,json,csv,io,hashlib,datetime,subprocess,sys,zipfile,shutil,argparse
p=pathlib.Path(__file__).parent;dist=p.parent/'painel-anm'/'dist';args=argparse.ArgumentParser();args.add_argument('--apply',action='store_true');opts=args.parse_args()
sources={'ResultadoRodadaDisponibilidade.csv':'SOPLE/ResultadoRodadaDisponibilidade.csv','EstoqueAreas.csv':'SOPLE/EstoqueAreas.csv','ResultadoAvaliacaoSocial.csv':'SOPLE/ResultadoAvaliacaoSocial.csv','InteressadoParticipante.csv':'SOPLE/InteressadoParticipante.csv','scm.zip':'SCM/microdados/microdados-scm.zip','BRASIL.zip':'SIGMINE/PROCESSOS_MINERARIOS/BRASIL.zip','PROCESSOS_INATIVOS.zip':'SIGMINE/PROCESSOS_MINERARIOS/PROCESSOS_INATIVOS.zip','CFEM_Arrecadacao_2017_2021.csv':'CFEM/CFEM_Arrecadacao_2017_2021.csv','CFEM_Arrecadacao_2022_2026.csv':'CFEM/CFEM_Arrecadacao_2022_2026.csv','InvestimentoPesquisaMineralMunicipio.csv':'DIPEM/InvestimentoPesquisaMineralMunicipio.csv'}
statefile=p/'source_state.json';state=json.loads(statefile.read_text()) if statefile.exists() else {};now=datetime.datetime.now(datetime.timezone.utc).isoformat();report={'checked_at':now,'changes':[],'errors':[],'complementary':[],'applied':False};stage=p/'pending_sources';stage.mkdir(exist_ok=True);newstate={};changed=[]
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while b:=f.read(1048576):h.update(b)
    return h.hexdigest()
for name,remote in sources.items():
    try:
        url='https://dadosabertos.anm.gov.br/'+remote;req=urllib.request.Request(url,headers={'User-Agent':'GeoLanceIA/1.0'},method='HEAD')
        with urllib.request.urlopen(req,timeout=60) as res:meta={'last_modified':res.headers.get('Last-Modified'),'etag':res.headers.get('ETag'),'content_length':res.headers.get('Content-Length')}
        report['complementary'].append({'file':name,**meta,'extracted_at':state.get(name,{}).get('extracted_at','2026-09-24')});newstate[name]={**meta,'extracted_at':state.get(name,{}).get('extracted_at','2026-09-24')}
        old=state.get(name,{})
        unchanged=old and all(old.get(k)==v for k,v in meta.items()) and bool(meta['last_modified'] or meta['etag'])
        if unchanged:continue
        target=stage/name
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'GeoLanceIA/1.0'}),timeout=180) as src,target.open('wb') as out:
            while b:=src.read(1048576):out.write(b)
        if meta['content_length']:assert target.stat().st_size==int(meta['content_length']),'Incomplete download'
        if digest(target)==digest(p/name):continue
        if name.endswith('.zip'):
            with zipfile.ZipFile(target) as z:assert z.testzip() is None,'Corrupt zip'
        else:
            enc='utf-8-sig' if remote.startswith('SOPLE/') else 'cp1252';delimiter=',' if name.startswith('CFEM_') else ';'
            with target.open(encoding=enc) as f:
                reader=csv.DictReader(f,delimiter=delimiter);oldreader=csv.DictReader((p/name).open(encoding=enc),delimiter=delimiter);assert reader.fieldnames==oldreader.fieldnames,'Schema changed: review required';n=0;rounds=set()
                for row in reader:
                    assert None not in row and all(v is not None for v in row.values()),'Malformed row';n+=1
                    if 'Rodada' in row:rounds.add(row['Rodada'])
                assert n>100,'Unexpected empty/small source'
                if rounds:assert rounds.issubset(set('12345678')),'New round: review rules before integrating'
        changed.append(name);report['changes'].append(name);newstate[name]['extracted_at']=now
    except Exception as e:report['errors'].append({'file':name,'error':str(e)})
if opts.apply and changed and not report['errors']:
    backup=p/'snapshots'/datetime.datetime.now().strftime('%Y%m%dT%H%M%S');backup.mkdir(parents=True,exist_ok=True)
    for name in changed:shutil.copy2(p/name,backup/name);shutil.copy2(stage/name,p/name)
    (p/'model_stale.flag').write_text('Sources changed. Frozen experiment remains historical; displayed predictions disabled pending review.')
    (p/'source_snapshot.json').write_text(json.dumps({'extracted_at':newstate['ResultadoRodadaDisponibilidade.csv']['extracted_at']}))
    # Remove only the old extracted geometry owned by this pipeline, within work/geometry.
    for name in changed:
        if name in ['BRASIL.zip','PROCESSOS_INATIVOS.zip']:
            directory=(p/'geometry'/name[:-4]).resolve();assert directory.is_relative_to((p/'geometry').resolve())
            for file in directory.glob('*'):
                if file.suffix.lower() in ['.shp','.shx','.dbf','.prj']:file.unlink()
    try:
        for script in ['integrate_scm.py','geo_extract.py','build_details.py','prepare_context.py','build_dashboard_data.py','build_overview.py','build_stock.py','build_database.py']:
            subprocess.run([sys.executable,str(p/script)],check=True)
        report['applied']=True
    except Exception as e:
        report['errors'].append({'file':'integration','error':str(e),'action':'Do not publish; restore/rebuild from snapshot before retry.'})
if not report['errors'] and (not changed or report['applied']):statefile.write_text(json.dumps(newstate,indent=2));
for source in report['complementary']:source['extracted_at']=newstate.get(source['file'],{}).get('extracted_at','2026-09-24')
(p/'pipeline_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
if not report['errors'] and (not changed or report['applied']):(dist/'freshness.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True));sys.exit(1 if report['errors'] else 0)
