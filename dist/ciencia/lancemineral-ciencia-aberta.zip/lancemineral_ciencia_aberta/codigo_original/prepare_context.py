"""Rebuild historical features and economic joins without fitting models."""
import pathlib
source=pathlib.Path(__file__).parent/'experiment_v2.py'
exec(compile(source.read_text(encoding='utf-8').split('y=np.array')[0],str(source),'exec'))
fields=['rodada','area','processo','situacao','lance_reais','corte_historico','uf','regime','hectares','eventos_anteriores','titulos_publicados','substancias_historicas','requerentes_titulares_historicos']
with (output/'base_analitica_inicial.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields,delimiter=';');w.writeheader()
    for r,e in zip(final,enhanced):w.writerow(dict(zip(fields,[r['Rodada'],r['NumeroArea'],r['ProcessoMinerario'],r['Situacao'],str(r['bid']),r['cutoff'],r['UnidadeFederacao'],r['RegimeDisponibilidade'],num(r['AreaPoligonal']),e['eventos_anteriores'],e['titulos_publicados'],e['substancias_historicas'],e['requerentes_titulares_historicos']])))
